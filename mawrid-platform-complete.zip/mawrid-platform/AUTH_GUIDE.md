# 🔐 دليل نظام الحماية والمصادقة - منصة مورد

## 📋 نظرة عامة

تم إضافة نظام حماية ومصادقة متكامل للمنصة يضمن أن:
- ✅ فقط الموظفين المصرح لهم يمكنهم الدخول
- ✅ كل موظف له صلاحيات محددة حسب دوره
- ✅ الموظف يمكنه الوصول فقط لمركزه الصحي
- ✅ جميع كلمات المرور مشفرة
- ✅ استخدام JWT للمصادقة الآمنة

---

## 👥 الأدوار (Roles)

### 1. Admin (مدير النظام)
- **الصلاحيات الكاملة**
- إدارة جميع المراكز الصحية
- إدارة المستخدمين (تفعيل/إلغاء تفعيل)
- الوصول لجميع البيانات والتقارير

### 2. Manager (مدير مركز)
- إدارة مركزه الصحي فقط
- إدارة المخزون في مركزه
- الموافقة على طلبات النقل
- عرض تقارير مركزه

### 3. Employee (موظف)
- إضافة وتعديل المخزون في مركزه
- طلب نقل الأصناف
- عرض سوق الفائض
- عرض بيانات مركزه

### 4. Viewer (عارض فقط)
- عرض البيانات فقط
- لا يمكنه التعديل
- مفيد للمراجعين والمراقبين

---

## 🔑 نظام المصادقة (Authentication)

### 1️⃣ التسجيل (Register)

**Endpoint:**
```
POST /api/auth/register
```

**Request Body:**
```json
{
  "username": "ahmed.mohammed",
  "email": "ahmed@health.sa",
  "password": "SecurePassword123!",
  "full_name": "Ahmed Mohammed",
  "full_name_ar": "أحمد محمد",
  "phone": "0551234567",
  "national_id": "1234567890",
  "employee_id": "EMP-001",
  "center_id": "uuid-of-health-center",
  "role": "employee"
}
```

**Response:**
```json
{
  "success": true,
  "message": "تم التسجيل بنجاح. يرجى انتظار تفعيل الحساب من المسؤول.",
  "data": {
    "user": {
      "id": "uuid",
      "username": "ahmed.mohammed",
      "email": "ahmed@health.sa",
      "full_name": "Ahmed Mohammed",
      "role": "employee",
      "is_active": true,
      "is_verified": false
    },
    "token": "jwt-token-here"
  }
}
```

**ملاحظات:**
- ✅ كلمة المرور تُشفّر تلقائياً باستخدام bcrypt
- ⚠️ الحساب يحتاج تفعيل من المسؤول (`is_verified: false`)
- 🔐 يتم إنشاء JWT token تلقائياً

---

### 2️⃣ تسجيل الدخول (Login)

**Endpoint:**
```
POST /api/auth/login
```

**Request Body:**
```json
{
  "email": "ahmed@health.sa",
  "password": "SecurePassword123!"
}
```

**Response:**
```json
{
  "success": true,
  "message": "تم تسجيل الدخول بنجاح",
  "data": {
    "user": {
      "id": "uuid",
      "username": "ahmed.mohammed",
      "email": "ahmed@health.sa",
      "full_name": "Ahmed Mohammed",
      "role": "employee",
      "center_id": "uuid",
      "health_center": {
        "id": "uuid",
        "name": "مركز الملك فهد الصحي",
        "city": "الرياض"
      }
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**حفظ الـ Token:**
```javascript
// في Frontend
localStorage.setItem('token', response.data.token);
localStorage.setItem('user', JSON.stringify(response.data.user));
```

---

### 3️⃣ الحصول على بيانات المستخدم الحالي

**Endpoint:**
```
GET /api/auth/me
```

**Headers:**
```
Authorization: Bearer <your-jwt-token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "username": "ahmed.mohammed",
    "email": "ahmed@health.sa",
    "full_name": "Ahmed Mohammed",
    "role": "employee",
    "health_center": {
      "id": "uuid",
      "name": "مركز الملك فهد الصحي",
      "city": "الرياض"
    }
  }
}
```

---

## 🛡️ حماية الـ Routes

### المستوى 1: المصادقة فقط (Authentication)

**أي مستخدم مسجل دخول:**

```javascript
const { authenticate } = require('../middleware/auth');

router.get('/api/inventory', authenticate, getAllInventory);
```

### المستوى 2: صلاحيات محددة (Authorization)

**فقط Admin:**

```javascript
const { authenticate, authorize } = require('../middleware/auth');

router.post('/api/health-centers', 
  authenticate, 
  authorize('admin'), 
  createCenter
);
```

**Admin أو Manager:**

```javascript
router.put('/api/transfers/:id/status', 
  authenticate, 
  authorize('admin', 'manager'), 
  updateTransferStatus
);
```

### المستوى 3: التحقق من المركز

**فقط موظفي نفس المركز:**

```javascript
const { authenticate, checkCenterAccess } = require('../middleware/auth');

router.get('/api/inventory/center/:center_id', 
  authenticate,
  checkCenterAccess,
  getInventoryByCenter
);
```

### المستوى 4: الحسابات المفعلة فقط

```javascript
const { authenticate, requireVerified } = require('../middleware/auth');

router.post('/api/transfers', 
  authenticate,
  requireVerified,
  createTransferRequest
);
```

---

## 🔧 استخدام المصادقة في Frontend

### 1. إنشاء Auth Context

```javascript
// src/context/AuthContext.jsx
import { createContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      fetchUser();
    } else {
      setLoading(false);
    }
  }, [token]);

  const fetchUser = async () => {
    try {
      const response = await authAPI.getMe();
      setUser(response.data.data);
    } catch (error) {
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    const response = await authAPI.login({ email, password });
    const { user, token } = response.data.data;
    
    localStorage.setItem('token', token);
    setToken(token);
    setUser(user);
    
    return response;
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
```

### 2. تحديث API Service

```javascript
// src/services/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
});

// إضافة Token تلقائياً
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// معالجة انتهاء الـ Token
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  getMe: () => api.get('/auth/me'),
  updateMe: (data) => api.put('/auth/me', data),
  changePassword: (data) => api.put('/auth/change-password', data),
};

export default api;
```

### 3. صفحة تسجيل الدخول

```javascript
// src/pages/Login.jsx
import { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await login(email, password);
      toast.success('تم تسجيل الدخول بنجاح');
      navigate('/');
    } catch (error) {
      toast.error(error.response?.data?.message || 'خطأ في تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100" dir="rtl">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-6">تسجيل الدخول</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">البريد الإلكتروني</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-2">كلمة المرور</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary-500 text-white py-2 rounded hover:bg-primary-600 disabled:opacity-50"
          >
            {loading ? 'جاري التحميل...' : 'دخول'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
```

### 4. حماية الـ Routes

```javascript
// src/components/ProtectedRoute.jsx
import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const ProtectedRoute = ({ children, roles }) => {
  const { user, loading } = useContext(AuthContext);

  if (loading) {
    return <div>جاري التحميل...</div>;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/unauthorized" />;
  }

  return children;
};

export default ProtectedRoute;
```

**الاستخدام:**

```javascript
// App.jsx
import ProtectedRoute from './components/ProtectedRoute';

<Routes>
  <Route path="/login" element={<Login />} />
  
  <Route path="/" element={
    <ProtectedRoute>
      <Dashboard />
    </ProtectedRoute>
  } />
  
  <Route path="/admin" element={
    <ProtectedRoute roles={['admin']}>
      <AdminPanel />
    </ProtectedRoute>
  } />
</Routes>
```

---

## 👤 إدارة المستخدمين (للمسؤول)

### جلب جميع المستخدمين

```
GET /api/auth/users
Authorization: Bearer <admin-token>
```

### تفعيل/إلغاء تفعيل مستخدم

```
PATCH /api/auth/users/:id/toggle-status
Authorization: Bearer <admin-token>
```

---

## 🔐 تغيير كلمة المرور

```
PUT /api/auth/change-password
Authorization: Bearer <your-token>

{
  "current_password": "OldPassword123!",
  "new_password": "NewSecurePassword123!"
}
```

---

## ⚙️ متغيرات البيئة المطلوبة

في `.env`:

```env
# JWT Configuration
JWT_SECRET=your_super_secret_jwt_key_minimum_32_characters_long
JWT_EXPIRE=7d
```

**⚠️ مهم جداً:**
- استخدم مفتاح سري قوي (32 حرف على الأقل)
- **لا تشارك** الـ JWT_SECRET أبداً
- غيّر المفتاح في الإنتاج

---

## 🎯 أمثلة على الصلاحيات

### مثال 1: موظف يطلب نقل صنف

```javascript
// ✅ يمكنه طلب نقل من مركزه
POST /api/transfers
{
  "item_id": "uuid",
  "sender_center_id": "his-center-uuid", // ✅
  "receiver_center_id": "other-center-uuid"
}

// ❌ لا يمكنه طلب نقل من مركز آخر
POST /api/transfers
{
  "sender_center_id": "not-his-center-uuid" // ❌ 403 Forbidden
}
```

### مثال 2: مدير يوافق على طلب

```javascript
// ✅ Manager يمكنه الموافقة على طلبات لمركزه فقط
PATCH /api/transfers/:id/status
{
  "status": "approved"
}
```

### مثال 3: مشرف يدير المستخدمين

```javascript
// ✅ Admin فقط
GET /api/auth/users
PATCH /api/auth/users/:id/toggle-status
```

---

## 🚨 رسائل الأخطاء

| Status | Message | السبب |
|--------|---------|-------|
| 401 | غير مصرح لك بالدخول | لم يتم تسجيل الدخول |
| 401 | رمز المصادقة غير صالح | Token منتهي أو خاطئ |
| 403 | حسابك غير نشط | تم إيقاف الحساب |
| 403 | ليس لديك صلاحية | الدور غير مناسب |
| 403 | يجب التحقق من حسابك أولاً | is_verified = false |

---

## ✅ Best Practices

1. **كلمات مرور قوية:**
   - 8 أحرف على الأقل
   - أحرف كبيرة وصغيرة
   - أرقام ورموز

2. **إدارة الـ Tokens:**
   - حفظها في localStorage
   - حذفها عند logout
   - تجديدها قبل انتهاء الصلاحية

3. **الأمان:**
   - HTTPS في الإنتاج
   - تشفير كلمات المرور (bcrypt) ✅
   - Rate limiting للـ login attempts
   - CORS محدد للدومينات المصرح بها

---

**🎉 نظام حماية متكامل واحترافي جاهز للاستخدام!**
