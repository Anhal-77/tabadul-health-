# 🐳 دليل Docker - منصة مورد

## 🚀 تشغيل المشروع باستخدام Docker

### المتطلبات:
- Docker Desktop (v20.10+)
- Docker Compose (v2.0+)

---

## ⚡ التشغيل السريع

### 1️⃣ تشغيل المشروع الكامل بأمر واحد:

```bash
docker-compose up -d
```

هذا الأمر سيقوم بـ:
- ✅ إنشاء قاعدة بيانات PostgreSQL
- ✅ بناء وتشغيل Backend API
- ✅ بناء وتشغيل Frontend
- ✅ ربط جميع الخدمات معاً

### 2️⃣ التحقق من أن الخدمات تعمل:

```bash
docker-compose ps
```

يجب أن تشاهد:
```
NAME                   STATUS    PORTS
mawrid-postgres        Up        0.0.0.0:5432->5432/tcp
mawrid-backend         Up        0.0.0.0:5000->5000/tcp
mawrid-frontend        Up        0.0.0.0:80->80/tcp
```

### 3️⃣ الوصول للتطبيق:

- **Frontend**: http://localhost
- **Backend API**: http://localhost:5000
- **Database**: localhost:5432

---

## 🔧 أوامر مفيدة

### عرض السجلات (Logs):

```bash
# جميع الخدمات
docker-compose logs -f

# خدمة محددة
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f postgres
```

### إيقاف الخدمات:

```bash
# إيقاف مع الاحتفاظ بالبيانات
docker-compose stop

# إيقاف وحذف الحاويات (البيانات محفوظة في volumes)
docker-compose down

# إيقاف وحذف كل شيء (بما فيها البيانات)
docker-compose down -v
```

### إعادة بناء الخدمات:

```bash
# إعادة بناء الكل
docker-compose up -d --build

# إعادة بناء خدمة محددة
docker-compose up -d --build backend
```

### الدخول لحاوية معينة:

```bash
# Backend
docker exec -it mawrid-backend sh

# Frontend
docker exec -it mawrid-frontend sh

# Database
docker exec -it mawrid-postgres psql -U mawrid_user -d mawrid_db
```

---

## 🌐 النشر على السحابة (Cloud Deployment)

### 1️⃣ AWS (Amazon Web Services)

#### استخدام ECS (Elastic Container Service):

```bash
# بناء وترفيع الـ images
docker build -t mawrid-backend ./backend
docker build -t mawrid-frontend ./frontend

# ترفيع للـ ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_URL
docker tag mawrid-backend:latest YOUR_ECR_URL/mawrid-backend:latest
docker push YOUR_ECR_URL/mawrid-backend:latest
```

#### استخدام RDS للقاعدة:
- إنشاء PostgreSQL RDS instance
- تحديث متغيرات البيئة في docker-compose

---

### 2️⃣ Google Cloud Platform (GCP)

#### استخدام Cloud Run:

```bash
# بناء وترفيع Backend
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/mawrid-backend ./backend
gcloud run deploy mawrid-backend --image gcr.io/YOUR_PROJECT_ID/mawrid-backend --platform managed

# بناء وترفيع Frontend
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/mawrid-frontend ./frontend
gcloud run deploy mawrid-frontend --image gcr.io/YOUR_PROJECT_ID/mawrid-frontend --platform managed
```

---

### 3️⃣ Azure

#### استخدام Azure Container Instances:

```bash
# إنشاء Container Registry
az acr create --resource-group mawrid-rg --name mawridregistry --sku Basic

# بناء وترفيع
az acr build --registry mawridregistry --image mawrid-backend:v1 ./backend
az acr build --registry mawridregistry --image mawrid-frontend:v1 ./frontend

# النشر
az container create --resource-group mawrid-rg --name mawrid-backend \
  --image mawridregistry.azurecr.io/mawrid-backend:v1 --ports 5000
```

---

### 4️⃣ DigitalOcean

#### استخدام App Platform:

1. ربط المشروع من GitHub
2. DigitalOcean سيكتشف تلقائياً ملفات Dockerfile
3. إعداد متغيرات البيئة
4. نشر التطبيق

أو استخدام doctl CLI:

```bash
# تثبيت doctl
brew install doctl

# المصادقة
doctl auth init

# إنشاء app
doctl apps create --spec .do/app.yaml
```

---

### 5️⃣ Railway

Railway يدعم Docker مباشرة:

1. اذهب إلى [railway.app](https://railway.app)
2. ربط GitHub repository
3. سيتم اكتشاف Dockerfile تلقائياً
4. إضافة PostgreSQL plugin
5. إعداد متغيرات البيئة
6. Deploy!

---

### 6️⃣ Render

```bash
# إنشاء render.yaml
services:
  - type: web
    name: mawrid-backend
    env: docker
    dockerfilePath: ./backend/Dockerfile
  
  - type: web
    name: mawrid-frontend
    env: docker
    dockerfilePath: ./frontend/Dockerfile
  
  - type: pserv
    name: mawrid-db
    env: docker
    plan: starter
```

---

## 🔐 الأمان في الإنتاج

### 1. متغيرات البيئة:

**لا تستخدم أبداً القيم الافتراضية في الإنتاج!**

قم بتعديل docker-compose.yml:

```yaml
environment:
  JWT_SECRET: ${JWT_SECRET}  # من ملف .env
  DB_PASSWORD: ${DB_PASSWORD}
```

### 2. استخدام Docker Secrets:

```yaml
secrets:
  db_password:
    file: ./secrets/db_password.txt

services:
  backend:
    secrets:
      - db_password
```

### 3. تشغيل كمستخدم غير root:

تم تطبيقه بالفعل في Dockerfile:

```dockerfile
USER nodejs  # ✅
```

### 4. استخدام Multi-stage builds:

تم تطبيقه في Frontend Dockerfile لتقليل حجم الـ image

---

## 📊 المراقبة (Monitoring)

### Health Checks:

جميع الخدمات لديها health checks في docker-compose.yml:

```bash
# التحقق من صحة الخدمات
docker-compose ps
```

### الموارد:

```bash
# استخدام الموارد
docker stats
```

---

## 🐛 حل المشاكل

### المشكلة: Backend لا يتصل بقاعدة البيانات

**الحل:**
```bash
# التحقق من logs
docker-compose logs postgres
docker-compose logs backend

# التحقق من الاتصال
docker exec -it mawrid-backend ping postgres
```

### المشكلة: Frontend لا يتصل بـ Backend

**الحل:**
تحديث متغيرات البيئة في frontend:
```env
VITE_API_URL=http://localhost:5000/api
```

### المشكلة: Port مستخدم مسبقاً

**الحل:**
تغيير المنافذ في docker-compose.yml:
```yaml
ports:
  - "8080:80"  # بدلاً من 80:80
```

---

## 📦 النسخ الاحتياطي

### نسخ احتياطي لقاعدة البيانات:

```bash
# إنشاء نسخة احتياطية
docker exec mawrid-postgres pg_dump -U mawrid_user mawrid_db > backup.sql

# استعادة النسخة
docker exec -i mawrid-postgres psql -U mawrid_user mawrid_db < backup.sql
```

### نسخ احتياطي للـ volumes:

```bash
# نسخ
docker run --rm --volumes-from mawrid-postgres -v $(pwd):/backup \
  alpine tar czf /backup/postgres-data-backup.tar.gz /var/lib/postgresql/data

# استعادة
docker run --rm --volumes-from mawrid-postgres -v $(pwd):/backup \
  alpine tar xzf /backup/postgres-data-backup.tar.gz -C /
```

---

## 🎯 أفضل الممارسات

1. ✅ **استخدم .dockerignore** - موجود بالفعل
2. ✅ **Multi-stage builds** - مطبق في Frontend
3. ✅ **Health checks** - موجودة في جميع الخدمات
4. ✅ **تشغيل كمستخدم غير root** - مطبق
5. ✅ **استخدام Alpine images** - لتقليل الحجم
6. ⚠️ **تحديث الـ secrets** - قبل الإنتاج!

---

## 📚 موارد إضافية

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/)
- [Best Practices](https://docs.docker.com/develop/dev-best-practices/)

---

**🎉 المشروع جاهز للنشر على أي منصة سحابية!**
