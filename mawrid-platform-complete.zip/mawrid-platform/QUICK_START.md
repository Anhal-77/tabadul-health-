# 🚀 دليل البدء السريع - منصة مورد

<div dir="rtl">

## ⚡ البدء في 5 دقائق

### 1️⃣ المتطلبات الأساسية
تأكد من تثبيت:
- Node.js (v18+) - [تحميل من هنا](https://nodejs.org/)
- PostgreSQL (v13+) - [تحميل من هنا](https://www.postgresql.org/download/)

---

## 🗄️ إعداد قاعدة البيانات

### افتح PostgreSQL Terminal:
```bash
psql -U postgres
```

### أنشئ قاعدة البيانات:
```sql
CREATE DATABASE mawrid_db;
\q
```

---

## 🔧 Backend Setup

```bash
# 1. انتقل إلى مجلد Backend
cd backend

# 2. ثبّت المكتبات
npm install

# 3. انسخ ملف البيئة
cp .env.example .env

# 4. عدّل ملف .env
# افتح .env وعدّل:
# DB_PASSWORD=كلمة_مرور_قاعدة_البيانات

# 5. شغّل الخادم
npm run dev
```

✅ **Backend جاهز!** - يعمل على `http://localhost:5000`

---

## 💻 Frontend Setup

```bash
# افتح نافذة Terminal جديدة

# 1. انتقل إلى مجلد Frontend
cd frontend

# 2. ثبّت المكتبات
npm install

# 3. انسخ ملف البيئة (اختياري)
cp .env.example .env

# 4. شغّل التطبيق
npm run dev
```

✅ **Frontend جاهز!** - يعمل على `http://localhost:3000`

---

## 🎯 افتح المتصفح

اذهب إلى: **http://localhost:3000**

---

## 📊 إضافة بيانات تجريبية (اختياري)

### أضف مركز صحي:
```bash
curl -X POST http://localhost:5000/api/health-centers \
-H "Content-Type: application/json" \
-d '{
  "name": "مركز الملك فهد الصحي",
  "name_ar": "مركز الملك فهد الصحي",
  "city": "الرياض",
  "region": "منطقة الرياض",
  "contact_info": {
    "phone": "0112345678",
    "email": "info@kingfahd.health.sa"
  },
  "manager_name": "د. أحمد محمد",
  "manager_email": "ahmad@kingfahd.health.sa"
}'
```

---

## 🐛 حل المشاكل الشائعة

### ❌ خطأ في الاتصال بقاعدة البيانات
**الحل:**
1. تأكد من تشغيل PostgreSQL
2. تحقق من بيانات الاتصال في `.env`
3. تأكد من إنشاء قاعدة البيانات `mawrid_db`

### ❌ Port 5000 أو 3000 مستخدم
**الحل:**
```bash
# غيّر PORT في backend/.env
PORT=5001

# غيّر port في frontend/vite.config.js
server: { port: 3001 }
```

### ❌ npm install فشل
**الحل:**
```bash
# احذف node_modules وأعد التثبيت
rm -rf node_modules
npm cache clean --force
npm install
```

---

## 📱 الخطوات التالية

1. ✅ استكشف لوحة التحكل
2. ✅ أضف مراكز صحية
3. ✅ أضف أصناف للمخزون
4. ✅ جرّب طلبات النقل
5. ✅ راجع التحليلات

---

## 🆘 تحتاج مساعدة؟

راجع **README.md** الكامل للمزيد من التفاصيل

**استمتع باستخدام منصة مورد! 🎉**

</div>
