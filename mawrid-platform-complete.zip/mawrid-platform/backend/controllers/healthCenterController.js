const { HealthCenter, Inventory, TransferRequest } = require('../models');
const { Op } = require('sequelize');

// Get all health centers
const getAllCenters = async (req, res) => {
  try {
    const { city, is_active } = req.query;
    
    const whereClause = {};
    if (city) whereClause.city = city;
    if (is_active !== undefined) whereClause.is_active = is_active === 'true';

    const centers = await HealthCenter.findAll({
      where: whereClause,
      order: [['name', 'ASC']],
      include: [{
        model: Inventory,
        as: 'inventory',
        attributes: ['id', 'item_name', 'quantity', 'status']
      }]
    });

    res.json({
      success: true,
      count: centers.length,
      data: centers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching health centers',
      error: error.message
    });
  }
};

// Get single health center by ID
const getCenterById = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id, {
      include: [
        {
          model: Inventory,
          as: 'inventory'
        },
        {
          model: TransferRequest,
          as: 'sentRequests',
          limit: 10,
          order: [['created_at', 'DESC']]
        },
        {
          model: TransferRequest,
          as: 'receivedRequests',
          limit: 10,
          order: [['created_at', 'DESC']]
        }
      ]
    });

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'Health center not found'
      });
    }

    res.json({
      success: true,
      data: center
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching health center',
      error: error.message
    });
  }
};

// Create new health center
const createCenter = async (req, res) => {
  try {
    const { name, city, contact_info } = req.body;

    const center = await HealthCenter.create({
      name,
      city,
      contact_info: contact_info || {}
    });

    res.status(201).json({
      success: true,
      message: 'Health center created successfully',
      data: center
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error creating health center',
      error: error.message
    });
  }
};

// Update health center
const updateCenter = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id);

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'Health center not found'
      });
    }

    await center.update(req.body);

    res.json({
      success: true,
      message: 'Health center updated successfully',
      data: center
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error updating health center',
      error: error.message
    });
  }
};

// Delete health center
const deleteCenter = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id);

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'Health center not found'
      });
    }

    await center.destroy();

    res.json({
      success: true,
      message: 'Health center deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting health center',
      error: error.message
    });
  }
};

module.exports = {
  getAllCenters,
  getCenterById,
  createCenter,
  updateCenter,
  deleteCenter
};
