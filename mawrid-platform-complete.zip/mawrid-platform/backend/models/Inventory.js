const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Inventory = sequelize.define('Inventory', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  center_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  item_name: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  category: {
    type: DataTypes.ENUM(
      'medicine',
      'dental_equipment',
      'medical_supplies',
      'diagnostic_tools',
      'other'
    ),
    allowNull: false,
    defaultValue: 'medical_supplies'
  },
  batch_number: {
    type: DataTypes.STRING(100),
    allowNull: true,
    unique: true
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
    validate: {
      min: 0
    }
  },
  expiry_date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    validate: {
      isDate: true
    }
  },
  status: {
    type: DataTypes.ENUM('available', 'surplus', 'critical', 'expired'),
    allowNull: false,
    defaultValue: 'available'
  },
  unit_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    defaultValue: 0.00
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'inventory',
  indexes: [
    {
      fields: ['center_id']
    },
    {
      fields: ['status']
    },
    {
      fields: ['category']
    },
    {
      fields: ['expiry_date']
    }
  ],
  hooks: {
    beforeSave: async (item) => {
      // Auto-update status based on expiry date and quantity
      const today = new Date();
      const expiryDate = new Date(item.expiry_date);
      const daysUntilExpiry = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));
      
      const criticalThreshold = parseInt(process.env.CRITICAL_QUANTITY_THRESHOLD) || 10;
      const expiryAlertDays = parseInt(process.env.EXPIRY_ALERT_DAYS) || 90;
      
      if (daysUntilExpiry <= 0) {
        item.status = 'expired';
      } else if (daysUntilExpiry <= expiryAlertDays && item.quantity > criticalThreshold) {
        item.status = 'surplus';
      } else if (item.quantity <= criticalThreshold && item.quantity > 0) {
        item.status = 'critical';
      } else if (item.quantity > 0) {
        item.status = 'available';
      }
    }
  }
});

module.exports = Inventory;
