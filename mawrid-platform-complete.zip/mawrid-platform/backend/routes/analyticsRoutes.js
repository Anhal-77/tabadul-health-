const express = require('express');
const router = express.Router();
const {
  getDashboardAnalytics,
  getWasteReductionStats,
  getCenterStatistics
} = require('../controllers/analyticsController');

// @route   GET /api/analytics/dashboard
// @desc    Get dashboard analytics
router.get('/dashboard', getDashboardAnalytics);

// @route   GET /api/analytics/waste-reduction
// @desc    Get waste reduction statistics
router.get('/waste-reduction', getWasteReductionStats);

// @route   GET /api/analytics/center/:center_id
// @desc    Get center-specific statistics
router.get('/center/:center_id', getCenterStatistics);

module.exports = router;
