const express = require('express');
const router = express.Router();
const {
  getAllCenters,
  getCenterById,
  createCenter,
  updateCenter,
  deleteCenter
} = require('../controllers/healthCenterController');

// @route   GET /api/centers
// @desc    Get all health centers
router.get('/', getAllCenters);

// @route   GET /api/centers/:id
// @desc    Get single health center by ID
router.get('/:id', getCenterById);

// @route   POST /api/centers
// @desc    Create new health center
router.post('/', createCenter);

// @route   PUT /api/centers/:id
// @desc    Update health center
router.put('/:id', updateCenter);

// @route   DELETE /api/centers/:id
// @desc    Delete health center
router.delete('/:id', deleteCenter);

module.exports = router;
