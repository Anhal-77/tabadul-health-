const express = require('express');
const router = express.Router();
const {
  getAllInventory,
  getSurplusItems,
  getCriticalItems,
  getInventoryById,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem
} = require('../controllers/inventoryController');

// @route   GET /api/inventory
// @desc    Get all inventory items
router.get('/', getAllInventory);

// @route   GET /api/inventory/surplus
// @desc    Get surplus items (expiring within 90 days)
router.get('/surplus', getSurplusItems);

// @route   GET /api/inventory/critical
// @desc    Get critical items (low quantity)
router.get('/critical', getCriticalItems);

// @route   GET /api/inventory/:id
// @desc    Get single inventory item
router.get('/:id', getInventoryById);

// @route   POST /api/inventory
// @desc    Create new inventory item
router.post('/', createInventoryItem);

// @route   PUT /api/inventory/:id
// @desc    Update inventory item
router.put('/:id', updateInventoryItem);

// @route   DELETE /api/inventory/:id
// @desc    Delete inventory item
router.delete('/:id', deleteInventoryItem);

module.exports = router;
