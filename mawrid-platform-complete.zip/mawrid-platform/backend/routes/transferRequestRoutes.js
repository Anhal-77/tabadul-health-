const express = require('express');
const router = express.Router();
const {
  getAllTransferRequests,
  getTransferRequestById,
  createTransferRequest,
  updateTransferStatus,
  deleteTransferRequest
} = require('../controllers/transferRequestController');

// @route   GET /api/transfers
// @desc    Get all transfer requests
router.get('/', getAllTransferRequests);

// @route   GET /api/transfers/:id
// @desc    Get single transfer request
router.get('/:id', getTransferRequestById);

// @route   POST /api/transfers
// @desc    Create new transfer request
router.post('/', createTransferRequest);

// @route   PUT /api/transfers/:id
// @desc    Update transfer request status
router.put('/:id', updateTransferStatus);

// @route   DELETE /api/transfers/:id
// @desc    Cancel transfer request
router.delete('/:id', deleteTransferRequest);

module.exports = router;
