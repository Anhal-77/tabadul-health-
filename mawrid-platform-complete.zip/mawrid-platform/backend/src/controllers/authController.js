const { User, HealthCenter } = require('../models');
const crypto = require('crypto');

/**
 * تسجيل مستخدم جديد
 */
exports.register = async (req, res) => {
  try {
    const {
      username,
      email,
      password,
      full_name,
      full_name_ar,
      phone,
      national_id,
      employee_id,
      center_id,
      role
    } = req.body;

    // التحقق من عدم وجود المستخدم مسبقاً
    const existingUser = await User.findOne({
      where: {
        [require('sequelize').Op.or]: [
          { email },
          { username },
          ...(national_id ? [{ national_id }] : []),
          ...(employee_id ? [{ employee_id }] : [])
        ]
      }
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'المستخدم موجود مسبقاً (البريد الإلكتروني أو اسم المستخدم أو الهوية)'
      });
    }

    // التحقق من وجود المركز إذا تم تحديده
    if (center_id) {
      const center = await HealthCenter.findByPk(center_id);
      if (!center) {
        return res.status(404).json({
          success: false,
          message: 'المركز الصحي غير موجود'
        });
      }
    }

    // إنشاء المستخدم (كلمة المرور ستُشفّر تلقائياً في الـ hook)
    const user = await User.create({
      username,
      email,
      password,
      full_name,
      full_name_ar,
      phone,
      national_id,
      employee_id,
      center_id,
      role: role || 'employee',
      is_verified: false // يحتاج تفعيل من المسؤول
    });

    // إنشاء token
    const token = user.generateAuthToken();

    // إخفاء كلمة المرور في الاستجابة
    const userResponse = user.toJSON();
    delete userResponse.password;

    res.status(201).json({
      success: true,
      message: 'تم التسجيل بنجاح. يرجى انتظار تفعيل الحساب من المسؤول.',
      data: {
        user: userResponse,
        token
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في التسجيل',
      error: error.message
    });
  }
};

/**
 * تسجيل الدخول
 */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // التحقق من إدخال البيانات
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'يرجى إدخال البريد الإلكتروني وكلمة المرور'
      });
    }

    // البحث عن المستخدم (نحتاج كلمة المرور للمقارنة)
    const user = await User.findOne({
      where: { email },
      include: [{
        model: HealthCenter,
        as: 'health_center',
        attributes: ['id', 'name', 'name_ar', 'city']
      }]
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
      });
    }

    // التحقق من كلمة المرور
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
      });
    }

    // التحقق من أن الحساب نشط
    if (!user.is_active) {
      return res.status(403).json({
        success: false,
        message: 'حسابك غير نشط. يرجى التواصل مع المسؤول.'
      });
    }

    // تحديث آخر تسجيل دخول
    await user.update({ last_login: new Date() });

    // إنشاء token
    const token = user.generateAuthToken();

    // إخفاء كلمة المرور في الاستجابة
    const userResponse = user.toJSON();
    delete userResponse.password;

    res.status(200).json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح',
      data: {
        user: userResponse,
        token
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تسجيل الدخول',
      error: error.message
    });
  }
};

/**
 * الحصول على معلومات المستخدم الحالي
 */
exports.getMe = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] },
      include: [{
        model: HealthCenter,
        as: 'health_center',
        attributes: ['id', 'name', 'name_ar', 'city', 'region']
      }]
    });

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    console.error('Get me error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب البيانات',
      error: error.message
    });
  }
};

/**
 * تحديث بيانات المستخدم الحالي
 */
exports.updateMe = async (req, res) => {
  try {
    const allowedFields = ['full_name', 'full_name_ar', 'phone'];
    const updates = {};

    allowedFields.forEach(field => {
      if (req.body[field]) {
        updates[field] = req.body[field];
      }
    });

    await req.user.update(updates);

    const updatedUser = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] }
    });

    res.status(200).json({
      success: true,
      message: 'تم تحديث البيانات بنجاح',
      data: updatedUser
    });
  } catch (error) {
    console.error('Update me error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث البيانات',
      error: error.message
    });
  }
};

/**
 * تغيير كلمة المرور
 */
exports.changePassword = async (req, res) => {
  try {
    const { current_password, new_password } = req.body;

    if (!current_password || !new_password) {
      return res.status(400).json({
        success: false,
        message: 'يرجى إدخال كلمة المرور الحالية والجديدة'
      });
    }

    // جلب المستخدم مع كلمة المرور
    const user = await User.findByPk(req.user.id);

    // التحقق من كلمة المرور الحالية
    const isMatch = await user.comparePassword(current_password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'كلمة المرور الحالية غير صحيحة'
      });
    }

    // تحديث كلمة المرور (ستُشفّر تلقائياً في الـ hook)
    await user.update({ password: new_password });

    res.status(200).json({
      success: true,
      message: 'تم تغيير كلمة المرور بنجاح'
    });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تغيير كلمة المرور',
      error: error.message
    });
  }
};

/**
 * جلب جميع المستخدمين (للمسؤول فقط)
 */
exports.getAllUsers = async (req, res) => {
  try {
    const { role, center_id, is_active } = req.query;

    const whereClause = {};
    if (role) whereClause.role = role;
    if (center_id) whereClause.center_id = center_id;
    if (is_active !== undefined) whereClause.is_active = is_active === 'true';

    const users = await User.findAll({
      where: whereClause,
      attributes: { exclude: ['password'] },
      include: [{
        model: HealthCenter,
        as: 'health_center',
        attributes: ['id', 'name', 'name_ar', 'city']
      }],
      order: [['created_at', 'DESC']]
    });

    res.status(200).json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب المستخدمين',
      error: error.message
    });
  }
};

/**
 * تفعيل/إلغاء تفعيل مستخدم (للمسؤول فقط)
 */
exports.toggleUserStatus = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'المستخدم غير موجود'
      });
    }

    await user.update({
      is_active: !user.is_active,
      is_verified: !user.is_active ? true : user.is_verified
    });

    const updatedUser = await User.findByPk(user.id, {
      attributes: { exclude: ['password'] }
    });

    res.status(200).json({
      success: true,
      message: `تم ${user.is_active ? 'تفعيل' : 'إلغاء تفعيل'} المستخدم بنجاح`,
      data: updatedUser
    });
  } catch (error) {
    console.error('Toggle user status error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث حالة المستخدم',
      error: error.message
    });
  }
};
