const { HealthCenter, Inventory } = require('../models');
const { Op } = require('sequelize');

/**
 * Get all health centers
 */
exports.getAllCenters = async (req, res) => {
  try {
    const { city, region, is_active } = req.query;
    
    const whereClause = {};
    if (city) whereClause.city = city;
    if (region) whereClause.region = region;
    if (is_active !== undefined) whereClause.is_active = is_active === 'true';

    const centers = await HealthCenter.findAll({
      where: whereClause,
      attributes: {
        exclude: ['createdAt', 'updatedAt']
      },
      order: [['name', 'ASC']]
    });

    res.status(200).json({
      success: true,
      count: centers.length,
      data: centers
    });
  } catch (error) {
    console.error('Error fetching health centers:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب المراكز الصحية',
      error: error.message
    });
  }
};

/**
 * Get single health center by ID
 */
exports.getCenterById = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id, {
      include: [{
        model: Inventory,
        as: 'inventory_items',
        attributes: ['id', 'item_name', 'category', 'quantity', 'status', 'expiry_date']
      }]
    });

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'المركز الصحي غير موجود'
      });
    }

    res.status(200).json({
      success: true,
      data: center
    });
  } catch (error) {
    console.error('Error fetching center:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب بيانات المركز',
      error: error.message
    });
  }
};

/**
 * Create new health center
 */
exports.createCenter = async (req, res) => {
  try {
    const {
      name,
      name_ar,
      city,
      region,
      contact_info,
      manager_name,
      manager_email
    } = req.body;

    const center = await HealthCenter.create({
      name,
      name_ar,
      city,
      region,
      contact_info,
      manager_name,
      manager_email,
      is_active: true
    });

    res.status(201).json({
      success: true,
      message: 'تم إنشاء المركز الصحي بنجاح',
      data: center
    });
  } catch (error) {
    console.error('Error creating center:', error);
    
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({
        success: false,
        message: 'اسم المركز موجود مسبقاً'
      });
    }

    res.status(500).json({
      success: false,
      message: 'خطأ في إنشاء المركز الصحي',
      error: error.message
    });
  }
};

/**
 * Update health center
 */
exports.updateCenter = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id);

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'المركز الصحي غير موجود'
      });
    }

    await center.update(req.body);

    res.status(200).json({
      success: true,
      message: 'تم تحديث المركز الصحي بنجاح',
      data: center
    });
  } catch (error) {
    console.error('Error updating center:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث المركز الصحي',
      error: error.message
    });
  }
};

/**
 * Delete health center
 */
exports.deleteCenter = async (req, res) => {
  try {
    const center = await HealthCenter.findByPk(req.params.id);

    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'المركز الصحي غير موجود'
      });
    }

    await center.destroy();

    res.status(200).json({
      success: true,
      message: 'تم حذف المركز الصحي بنجاح'
    });
  } catch (error) {
    console.error('Error deleting center:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في حذف المركز الصحي',
      error: error.message
    });
  }
};

/**
 * Get centers statistics
 */
exports.getCentersStats = async (req, res) => {
  try {
    const totalCenters = await HealthCenter.count();
    const activeCenters = await HealthCenter.count({ where: { is_active: true } });
    
    const centersByCity = await HealthCenter.findAll({
      attributes: [
        'city',
        [require('sequelize').fn('COUNT', require('sequelize').col('id')), 'count']
      ],
      group: ['city'],
      raw: true
    });

    res.status(200).json({
      success: true,
      data: {
        total_centers: totalCenters,
        active_centers: activeCenters,
        inactive_centers: totalCenters - activeCenters,
        centers_by_city: centersByCity
      }
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الإحصائيات',
      error: error.message
    });
  }
};
