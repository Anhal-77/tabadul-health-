const { TransferRequest, Inventory, HealthCenter } = require('../models');
const { Op } = require('sequelize');

/**
 * Get all transfer requests
 */
exports.getAllRequests = async (req, res) => {
  try {
    const { 
      status, 
      sender_center_id, 
      receiver_center_id,
      page = 1,
      limit = 50
    } = req.query;

    const whereClause = {};
    if (status) whereClause.status = status;
    if (sender_center_id) whereClause.sender_center_id = sender_center_id;
    if (receiver_center_id) whereClause.receiver_center_id = receiver_center_id;

    const offset = (page - 1) * limit;

    const { count, rows: requests } = await TransferRequest.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: HealthCenter,
          as: 'sender_center',
          attributes: ['id', 'name', 'name_ar', 'city']
        },
        {
          model: HealthCenter,
          as: 'receiver_center',
          attributes: ['id', 'name', 'name_ar', 'city']
        },
        {
          model: Inventory,
          as: 'inventory_item',
          attributes: ['id', 'item_name', 'item_name_ar', 'category', 'expiry_date', 'unit']
        }
      ],
      limit: parseInt(limit),
      offset: offset,
      order: [['request_date', 'DESC']]
    });

    res.status(200).json({
      success: true,
      count: count,
      total_pages: Math.ceil(count / limit),
      current_page: parseInt(page),
      data: requests
    });
  } catch (error) {
    console.error('Error fetching transfer requests:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب طلبات النقل',
      error: error.message
    });
  }
};

/**
 * Get single transfer request
 */
exports.getRequestById = async (req, res) => {
  try {
    const request = await TransferRequest.findByPk(req.params.id, {
      include: [
        {
          model: HealthCenter,
          as: 'sender_center'
        },
        {
          model: HealthCenter,
          as: 'receiver_center'
        },
        {
          model: Inventory,
          as: 'inventory_item'
        }
      ]
    });

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'الطلب غير موجود'
      });
    }

    res.status(200).json({
      success: true,
      data: request
    });
  } catch (error) {
    console.error('Error fetching request:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الطلب',
      error: error.message
    });
  }
};

/**
 * Create new transfer request
 */
exports.createRequest = async (req, res) => {
  try {
    const {
      item_id,
      sender_center_id,
      receiver_center_id,
      quantity,
      priority,
      requester_name,
      requester_email,
      reason
    } = req.body;

    // Validate item exists and has enough quantity
    const item = await Inventory.findByPk(item_id);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'الصنف غير موجود'
      });
    }

    if (item.quantity < quantity) {
      return res.status(400).json({
        success: false,
        message: 'الكمية المطلوبة غير متوفرة'
      });
    }

    // Verify centers exist
    const senderCenter = await HealthCenter.findByPk(sender_center_id);
    const receiverCenter = await HealthCenter.findByPk(receiver_center_id);

    if (!senderCenter || !receiverCenter) {
      return res.status(404).json({
        success: false,
        message: 'أحد المراكز الصحية غير موجود'
      });
    }

    if (sender_center_id === receiver_center_id) {
      return res.status(400).json({
        success: false,
        message: 'لا يمكن النقل إلى نفس المركز'
      });
    }

    // Generate tracking number
    const trackingNumber = `TR-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

    // Calculate estimated value
    const estimatedValue = quantity * (item.unit_price || 0);

    const request = await TransferRequest.create({
      item_id,
      sender_center_id,
      receiver_center_id,
      quantity,
      priority: priority || 'medium',
      requester_name,
      requester_email,
      reason,
      tracking_number: trackingNumber,
      estimated_value: estimatedValue,
      status: 'pending'
    });

    // Update item status to reserved
    await item.update({ status: 'reserved' });

    const fullRequest = await TransferRequest.findByPk(request.id, {
      include: [
        { model: HealthCenter, as: 'sender_center' },
        { model: HealthCenter, as: 'receiver_center' },
        { model: Inventory, as: 'inventory_item' }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'تم إنشاء الطلب بنجاح',
      data: fullRequest
    });
  } catch (error) {
    console.error('Error creating request:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في إنشاء الطلب',
      error: error.message
    });
  }
};

/**
 * Update transfer request status
 */
exports.updateRequestStatus = async (req, res) => {
  try {
    const { status, rejection_reason, notes } = req.body;
    const request = await TransferRequest.findByPk(req.params.id);

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'الطلب غير موجود'
      });
    }

    const updateData = { status };

    // Set appropriate date fields based on status
    if (status === 'approved') {
      updateData.approval_date = new Date();
    } else if (status === 'shipped') {
      updateData.shipped_date = new Date();
    } else if (status === 'received') {
      updateData.received_date = new Date();
      
      // Transfer the inventory
      const item = await Inventory.findByPk(request.item_id);
      if (item) {
        // Reduce quantity from sender
        await item.update({
          quantity: item.quantity - request.quantity,
          status: item.quantity - request.quantity > 0 ? item.status : 'available'
        });

        // Add to receiver (check if item exists in receiver's inventory)
        const receiverItem = await Inventory.findOne({
          where: {
            center_id: request.receiver_center_id,
            batch_number: item.batch_number
          }
        });

        if (receiverItem) {
          // Update existing item
          await receiverItem.update({
            quantity: receiverItem.quantity + request.quantity
          });
        } else {
          // Create new item in receiver's inventory
          await Inventory.create({
            center_id: request.receiver_center_id,
            item_name: item.item_name,
            item_name_ar: item.item_name_ar,
            category: item.category,
            batch_number: item.batch_number,
            quantity: request.quantity,
            unit: item.unit,
            expiry_date: item.expiry_date,
            unit_price: item.unit_price,
            manufacturer: item.manufacturer,
            status: 'available'
          });
        }
      }
    } else if (status === 'rejected' || status === 'cancelled') {
      updateData.rejection_reason = rejection_reason;
      
      // Release the reserved item
      const item = await Inventory.findByPk(request.item_id);
      if (item && item.status === 'reserved') {
        await item.update({ status: 'surplus' });
      }
    }

    if (notes) updateData.notes = notes;

    await request.update(updateData);

    const updatedRequest = await TransferRequest.findByPk(request.id, {
      include: [
        { model: HealthCenter, as: 'sender_center' },
        { model: HealthCenter, as: 'receiver_center' },
        { model: Inventory, as: 'inventory_item' }
      ]
    });

    res.status(200).json({
      success: true,
      message: 'تم تحديث حالة الطلب بنجاح',
      data: updatedRequest
    });
  } catch (error) {
    console.error('Error updating request:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث حالة الطلب',
      error: error.message
    });
  }
};

/**
 * Delete transfer request
 */
exports.deleteRequest = async (req, res) => {
  try {
    const request = await TransferRequest.findByPk(req.params.id);

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'الطلب غير موجود'
      });
    }

    // Only allow deletion of pending requests
    if (request.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'لا يمكن حذف طلب تم معالجته'
      });
    }

    // Release reserved item
    const item = await Inventory.findByPk(request.item_id);
    if (item && item.status === 'reserved') {
      await item.update({ status: 'surplus' });
    }

    await request.destroy();

    res.status(200).json({
      success: true,
      message: 'تم حذف الطلب بنجاح'
    });
  } catch (error) {
    console.error('Error deleting request:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في حذف الطلب',
      error: error.message
    });
  }
};

/**
 * Get transfer statistics
 */
exports.getTransferStats = async (req, res) => {
  try {
    const { sequelize } = require('../config/database');
    
    const totalRequests = await TransferRequest.count();
    
    const requestsByStatus = await TransferRequest.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('estimated_value')), 'total_value']
      ],
      group: ['status'],
      raw: true
    });

    const receivedRequests = await TransferRequest.findAll({
      where: { status: 'received' },
      attributes: [
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_items'],
        [sequelize.fn('SUM', sequelize.col('estimated_value')), 'total_value_saved']
      ],
      raw: true
    });

    res.status(200).json({
      success: true,
      data: {
        total_requests: totalRequests,
        requests_by_status: requestsByStatus,
        waste_prevention: receivedRequests[0]
      }
    });
  } catch (error) {
    console.error('Error fetching transfer stats:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب إحصائيات النقل',
      error: error.message
    });
  }
};
