const jwt = require('jsonwebtoken');
const { User } = require('../models');

/**
 * Middleware للتحقق من صحة الـ JWT Token
 */
exports.authenticate = async (req, res, next) => {
  try {
    // الحصول على الـ token من الـ header
    let token;
    
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    // التحقق من وجود token
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'غير مصرح لك بالدخول. يرجى تسجيل الدخول.'
      });
    }

    try {
      // التحقق من صحة الـ token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // جلب بيانات المستخدم
      const user = await User.findByPk(decoded.id, {
        attributes: { exclude: ['password'] },
        include: [{
          model: require('./HealthCenter'),
          as: 'health_center',
          attributes: ['id', 'name', 'name_ar', 'city']
        }]
      });

      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'المستخدم غير موجود'
        });
      }

      // التحقق من أن الحساب نشط
      if (!user.is_active) {
        return res.status(403).json({
          success: false,
          message: 'حسابك غير نشط. يرجى التواصل مع المسؤول.'
        });
      }

      // إضافة بيانات المستخدم للـ request
      req.user = user;
      next();
    } catch (error) {
      return res.status(401).json({
        success: false,
        message: 'رمز المصادقة غير صالح أو منتهي الصلاحية'
      });
    }
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في المصادقة',
      error: error.message
    });
  }
};

/**
 * Middleware للتحقق من الصلاحيات (Authorization)
 * @param  {...any} roles - الأدوار المسموح لها (admin, manager, employee, viewer)
 */
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'غير مصرح لك بالدخول'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك صلاحية للوصول إلى هذا المورد',
        required_role: roles,
        your_role: req.user.role
      });
    }

    next();
  };
};

/**
 * Middleware للتحقق من أن المستخدم يعمل في نفس المركز
 */
exports.checkCenterAccess = async (req, res, next) => {
  try {
    const { center_id } = req.params.center_id ? req.params : req.body;

    // المشرف له صلاحية على كل المراكز
    if (req.user.role === 'admin') {
      return next();
    }

    // التحقق من أن المستخدم يعمل في نفس المركز
    if (req.user.center_id !== center_id) {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك صلاحية الوصول إلى هذا المركز'
      });
    }

    next();
  } catch (error) {
    console.error('Center access check error:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في التحقق من الصلاحيات',
      error: error.message
    });
  }
};

/**
 * Middleware للتحقق من أن الحساب تم التحقق منه
 */
exports.requireVerified = (req, res, next) => {
  if (!req.user.is_verified) {
    return res.status(403).json({
      success: false,
      message: 'يجب التحقق من حسابك أولاً. يرجى التواصل مع المسؤول.'
    });
  }
  next();
};

/**
 * Middleware اختياري للمصادقة (للصفحات العامة)
 */
exports.optionalAuth = async (req, res, next) => {
  try {
    let token;
    
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id, {
          attributes: { exclude: ['password'] }
        });
        
        if (user && user.is_active) {
          req.user = user;
        }
      } catch (error) {
        // تجاهل الأخطاء في المصادقة الاختيارية
      }
    }

    next();
  } catch (error) {
    next();
  }
};
