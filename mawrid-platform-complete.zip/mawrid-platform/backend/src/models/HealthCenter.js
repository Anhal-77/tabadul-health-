const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const HealthCenter = sequelize.define('health_centers', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING(200),
    allowNull: false,
    unique: true
  },
  name_ar: {
    type: DataTypes.STRING(200),
    allowNull: true,
    comment: 'Arabic name of the health center'
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  region: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  contact_info: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'JSON object containing phone, email, address'
  },
  manager_name: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  manager_email: {
    type: DataTypes.STRING(150),
    allowNull: true,
    validate: {
      isEmail: true
    }
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  total_inventory_value: {
    type: DataTypes.DECIMAL(12, 2),
    defaultValue: 0.00
  },
  last_activity_date: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'health_centers',
  timestamps: true,
  indexes: [
    {
      unique: false,
      fields: ['city']
    },
    {
      unique: false,
      fields: ['is_active']
    }
  ]
});

module.exports = HealthCenter;
