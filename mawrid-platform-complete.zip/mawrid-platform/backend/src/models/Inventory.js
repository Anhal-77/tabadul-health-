const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Inventory = sequelize.define('inventory', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  center_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  item_name: {
    type: DataTypes.STRING(250),
    allowNull: false
  },
  item_name_ar: {
    type: DataTypes.STRING(250),
    allowNull: true,
    comment: 'Arabic name of the item'
  },
  category: {
    type: DataTypes.ENUM(
      'medications',
      'dental_supplies',
      'medical_equipment',
      'consumables',
      'vaccines',
      'other'
    ),
    allowNull: false,
    defaultValue: 'other'
  },
  batch_number: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 0
    }
  },
  unit: {
    type: DataTypes.STRING(50),
    defaultValue: 'unit',
    comment: 'Unit of measurement (box, bottle, unit, etc.)'
  },
  expiry_date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('available', 'surplus', 'critical', 'expired', 'reserved'),
    allowNull: false,
    defaultValue: 'available'
  },
  unit_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    defaultValue: 0.00
  },
  total_value: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: true,
    defaultValue: 0.00
  },
  manufacturer: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  storage_location: {
    type: DataTypes.STRING(100),
    allowNull: true,
    comment: 'Shelf or room location in the center'
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  days_until_expiry: {
    type: DataTypes.VIRTUAL,
    get() {
      const today = new Date();
      const expiry = new Date(this.expiry_date);
      const diffTime = expiry - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    }
  }
}, {
  tableName: 'inventory',
  timestamps: true,
  indexes: [
    {
      unique: false,
      fields: ['center_id']
    },
    {
      unique: false,
      fields: ['status']
    },
    {
      unique: false,
      fields: ['category']
    },
    {
      unique: false,
      fields: ['expiry_date']
    },
    {
      unique: true,
      fields: ['center_id', 'batch_number']
    }
  ],
  hooks: {
    beforeSave: (inventory) => {
      // Calculate total value
      inventory.total_value = inventory.quantity * (inventory.unit_price || 0);
    }
  }
});

module.exports = Inventory;
