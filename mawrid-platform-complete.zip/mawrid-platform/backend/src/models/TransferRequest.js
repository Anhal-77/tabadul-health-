const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const TransferRequest = sequelize.define('transfer_requests', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  item_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'inventory',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  sender_center_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    }
  },
  receiver_center_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    }
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1
    }
  },
  status: {
    type: DataTypes.ENUM(
      'pending',
      'approved',
      'rejected',
      'shipped',
      'received',
      'cancelled'
    ),
    allowNull: false,
    defaultValue: 'pending'
  },
  request_date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  approval_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  shipped_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  received_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  tracking_number: {
    type: DataTypes.STRING(100),
    allowNull: true,
    unique: true
  },
  priority: {
    type: DataTypes.ENUM('low', 'medium', 'high', 'urgent'),
    defaultValue: 'medium'
  },
  requester_name: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  requester_email: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  reason: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'Reason for the transfer request'
  },
  rejection_reason: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  estimated_value: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    defaultValue: 0.00
  }
}, {
  tableName: 'transfer_requests',
  timestamps: true,
  indexes: [
    {
      unique: false,
      fields: ['item_id']
    },
    {
      unique: false,
      fields: ['sender_center_id']
    },
    {
      unique: false,
      fields: ['receiver_center_id']
    },
    {
      unique: false,
      fields: ['status']
    },
    {
      unique: false,
      fields: ['request_date']
    }
  ],
  validate: {
    differentCenters() {
      if (this.sender_center_id === this.receiver_center_id) {
        throw new Error('Sender and receiver centers cannot be the same');
      }
    }
  }
});

module.exports = TransferRequest;
