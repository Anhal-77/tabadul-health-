const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcryptjs');

const User = sequelize.define('users', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  username: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
    validate: {
      len: [3, 100]
    }
  },
  email: {
    type: DataTypes.STRING(150),
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      len: [6, 255]
    }
  },
  full_name: {
    type: DataTypes.STRING(200),
    allowNull: false
  },
  full_name_ar: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  role: {
    type: DataTypes.ENUM('admin', 'manager', 'employee', 'viewer'),
    allowNull: false,
    defaultValue: 'employee',
    comment: 'admin: مدير النظام، manager: مدير مركز، employee: موظف، viewer: عارض فقط'
  },
  center_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'health_centers',
      key: 'id'
    },
    comment: 'المركز الصحي التابع له الموظف'
  },
  phone: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  national_id: {
    type: DataTypes.STRING(20),
    allowNull: true,
    unique: true,
    comment: 'رقم الهوية الوطنية'
  },
  employee_id: {
    type: DataTypes.STRING(50),
    allowNull: true,
    unique: true,
    comment: 'الرقم الوظيفي'
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  is_verified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    comment: 'تم التحقق من الحساب'
  },
  last_login: {
    type: DataTypes.DATE,
    allowNull: true
  },
  reset_password_token: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  reset_password_expire: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'users',
  timestamps: true,
  indexes: [
    {
      unique: false,
      fields: ['role']
    },
    {
      unique: false,
      fields: ['center_id']
    },
    {
      unique: false,
      fields: ['is_active']
    }
  ],
  hooks: {
    // تشفير كلمة المرور قبل الحفظ
    beforeCreate: async (user) => {
      if (user.password) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    }
  }
});

// Method لمقارنة كلمة المرور
User.prototype.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method لتوليد JWT token
User.prototype.generateAuthToken = function() {
  const jwt = require('jsonwebtoken');
  return jwt.sign(
    { 
      id: this.id, 
      email: this.email, 
      role: this.role,
      center_id: this.center_id 
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE || '7d' }
  );
};

module.exports = User;
