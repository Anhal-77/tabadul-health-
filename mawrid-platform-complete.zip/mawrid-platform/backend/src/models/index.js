const { sequelize } = require('../config/database');
const HealthCenter = require('./HealthCenter');
const Inventory = require('./Inventory');
const TransferRequest = require('./TransferRequest');
const User = require('./User');

// Define Relationships

// User belongs to HealthCenter
User.belongsTo(HealthCenter, {
  foreignKey: 'center_id',
  as: 'health_center'
});

// HealthCenter has many Users
HealthCenter.hasMany(User, {
  foreignKey: 'center_id',
  as: 'users'
});

// HealthCenter has many Inventory items
HealthCenter.hasMany(Inventory, {
  foreignKey: 'center_id',
  as: 'inventory_items',
  onDelete: 'CASCADE'
});

Inventory.belongsTo(HealthCenter, {
  foreignKey: 'center_id',
  as: 'health_center'
});

// HealthCenter has many TransferRequests as sender
HealthCenter.hasMany(TransferRequest, {
  foreignKey: 'sender_center_id',
  as: 'sent_requests'
});

// HealthCenter has many TransferRequests as receiver
HealthCenter.hasMany(TransferRequest, {
  foreignKey: 'receiver_center_id',
  as: 'received_requests'
});

// TransferRequest belongs to HealthCenter (sender)
TransferRequest.belongsTo(HealthCenter, {
  foreignKey: 'sender_center_id',
  as: 'sender_center'
});

// TransferRequest belongs to HealthCenter (receiver)
TransferRequest.belongsTo(HealthCenter, {
  foreignKey: 'receiver_center_id',
  as: 'receiver_center'
});

// Inventory has many TransferRequests
Inventory.hasMany(TransferRequest, {
  foreignKey: 'item_id',
  as: 'transfer_requests'
});

// TransferRequest belongs to Inventory
TransferRequest.belongsTo(Inventory, {
  foreignKey: 'item_id',
  as: 'inventory_item'
});

// Sync all models
const syncDatabase = async (options = {}) => {
  try {
    await sequelize.sync(options);
    console.log('✅ Database synchronized successfully');
  } catch (error) {
    console.error('❌ Error synchronizing database:', error);
    throw error;
  }
};

module.exports = {
  sequelize,
  HealthCenter,
  Inventory,
  TransferRequest,
  User,
  syncDatabase
};
