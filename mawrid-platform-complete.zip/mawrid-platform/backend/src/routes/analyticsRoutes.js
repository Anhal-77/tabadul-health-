const express = require('express');
const router = express.Router();
const {
  getDashboardAnalytics,
  getWastePreventionReport,
  getCenterAnalytics
} = require('../controllers/analyticsController');

/**
 * @route   GET /api/analytics/dashboard
 * @desc    Get comprehensive dashboard analytics
 * @access  Public
 */
router.get('/dashboard', getDashboardAnalytics);

/**
 * @route   GET /api/analytics/waste-prevention
 * @desc    Get waste prevention report
 * @access  Public
 */
router.get('/waste-prevention', getWastePreventionReport);

/**
 * @route   GET /api/analytics/center/:center_id
 * @desc    Get center-specific analytics
 * @access  Public
 */
router.get('/center/:center_id', getCenterAnalytics);

module.exports = router;
