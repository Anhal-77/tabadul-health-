const express = require('express');
const router = express.Router();
const {
  register,
  login,
  getMe,
  updateMe,
  changePassword,
  getAllUsers,
  toggleUserStatus
} = require('../controllers/authController');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route   POST /api/auth/register
 * @desc    تسجيل مستخدم جديد
 * @access  Public
 */
router.post('/register', register);

/**
 * @route   POST /api/auth/login
 * @desc    تسجيل الدخول
 * @access  Public
 */
router.post('/login', login);

/**
 * @route   GET /api/auth/me
 * @desc    الحصول على معلومات المستخدم الحالي
 * @access  Private
 */
router.get('/me', authenticate, getMe);

/**
 * @route   PUT /api/auth/me
 * @desc    تحديث بيانات المستخدم الحالي
 * @access  Private
 */
router.put('/me', authenticate, updateMe);

/**
 * @route   PUT /api/auth/change-password
 * @desc    تغيير كلمة المرور
 * @access  Private
 */
router.put('/change-password', authenticate, changePassword);

/**
 * @route   GET /api/auth/users
 * @desc    جلب جميع المستخدمين (للمسؤول فقط)
 * @access  Private/Admin
 */
router.get('/users', authenticate, authorize('admin'), getAllUsers);

/**
 * @route   PATCH /api/auth/users/:id/toggle-status
 * @desc    تفعيل/إلغاء تفعيل مستخدم (للمسؤول فقط)
 * @access  Private/Admin
 */
router.patch('/users/:id/toggle-status', authenticate, authorize('admin'), toggleUserStatus);

module.exports = router;
