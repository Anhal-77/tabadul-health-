const express = require('express');
const router = express.Router();
const {
  getAllCenters,
  getCenterById,
  createCenter,
  updateCenter,
  deleteCenter,
  getCentersStats
} = require('../controllers/healthCenterController');

/**
 * @route   GET /api/health-centers
 * @desc    Get all health centers
 * @access  Public
 */
router.get('/', getAllCenters);

/**
 * @route   GET /api/health-centers/stats
 * @desc    Get health centers statistics
 * @access  Public
 */
router.get('/stats', getCentersStats);

/**
 * @route   GET /api/health-centers/:id
 * @desc    Get single health center by ID
 * @access  Public
 */
router.get('/:id', getCenterById);

/**
 * @route   POST /api/health-centers
 * @desc    Create new health center
 * @access  Public (should be protected in production)
 */
router.post('/', createCenter);

/**
 * @route   PUT /api/health-centers/:id
 * @desc    Update health center
 * @access  Public (should be protected in production)
 */
router.put('/:id', updateCenter);

/**
 * @route   DELETE /api/health-centers/:id
 * @desc    Delete health center
 * @access  Public (should be protected in production)
 */
router.delete('/:id', deleteCenter);

module.exports = router;
