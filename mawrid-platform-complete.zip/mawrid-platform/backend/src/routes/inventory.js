const express = require('express');
const router = express.Router();
const inventoryController = require('../controllers/inventoryController');

// GET /api/inventory - Get all inventory items
router.get('/', inventoryController.getAll);

// GET /api/inventory/surplus - Get surplus items
router.get('/surplus', inventoryController.getSurplus);

// GET /api/inventory/stats/:center_id? - Get inventory statistics
router.get('/stats/:center_id?', inventoryController.getStats);

// GET /api/inventory/:id - Get single inventory item
router.get('/:id', inventoryController.getById);

// POST /api/inventory - Create new inventory item
router.post('/', inventoryController.create);

// PUT /api/inventory/:id - Update inventory item
router.put('/:id', inventoryController.update);

// DELETE /api/inventory/:id - Delete inventory item
router.delete('/:id', inventoryController.delete);

module.exports = router;
