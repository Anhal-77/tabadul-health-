const cron = require('node-cron');
const { Inventory } = require('../models');
const { Op } = require('sequelize');

// Run every day at midnight to update inventory status
const scheduleInventoryStatusUpdate = () => {
  cron.schedule('0 0 * * *', async () => {
    console.log('🔄 Running scheduled inventory status update...');
    
    try {
      const allItems = await Inventory.findAll();
      
      for (const item of allItems) {
        // Save will trigger the beforeSave hook which updates status
        await item.save();
      }
      
      console.log('✅ Inventory status updated successfully');
    } catch (error) {
      console.error('❌ Error updating inventory status:', error.message);
    }
  });
  
  console.log('📅 Scheduled daily inventory status update at midnight');
};

module.exports = { scheduleInventoryStatusUpdate };
