import { Link, useLocation } from 'react-router-dom';
import { FaHome, FaStore, FaBoxes, FaExchangeAlt, FaHospital } from 'react-icons/fa';

const Navbar = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'الرئيسية', icon: <FaHome /> },
    { path: '/marketplace', label: 'سوق الفائض', icon: <FaStore /> },
    { path: '/inventory', label: 'المخزون', icon: <FaBoxes /> },
    { path: '/transfers', label: 'طلبات النقل', icon: <FaExchangeAlt /> },
    { path: '/centers', label: 'المراكز الصحية', icon: <FaHospital /> },
  ];

  return (
    <nav className="bg-primary-600 shadow-lg" dir="rtl">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 space-x-reverse">
            <div className="bg-white p-2 rounded-lg">
              <FaHospital className="text-primary-600 text-2xl" />
            </div>
            <div>
              <h1 className="text-white font-bold text-xl">منصة مورد</h1>
              <p className="text-primary-100 text-xs">Mawrid Platform</p>
            </div>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex space-x-4 space-x-reverse">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  location.pathname === item.path
                    ? 'bg-primary-700 text-white'
                    : 'text-primary-100 hover:bg-primary-700 hover:text-white'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
