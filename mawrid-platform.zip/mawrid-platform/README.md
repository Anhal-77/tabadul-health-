# 🏥 منصة مورد | Mawrid Platform

<div dir="rtl">

## 📋 نبذة عن المشروع

**منصة مورد** هي نظام متكامل لإدارة الموارد الصحية المشتركة بين المراكز الصحية الحكومية في المملكة العربية السعودية. تهدف المنصة إلى تقليل الهدر المالي الناتج عن انتهاء صلاحية الأدوية والمستلزمات الطبية من خلال تمكين المراكز من مشاركة الفائض قبل انتهاء صلاحيته.

### 🎯 المشكلة
- هدر مالي كبير بسبب انتهاء صلاحية الأدوية والمستلزمات الطبية
- عدم وجود آلية فعالة لمشاركة الموارد بين المراكز الصحية
- صعوبة تتبع المخزون والأصناف القريبة من انتهاء الصلاحية

### 💡 الحل
منصة رقمية متكاملة توفر:
- **نظام تنبيهات ذكي**: يحدد تلقائياً الأصناف التي تنتهي صلاحيتها خلال 90 يوماً
- **سوق إلكتروني**: لاستعراض وطلب الفائض من المراكز الأخرى
- **لوحة تحليلات**: لقياس الهدر المالي الذي تم تجنبه

</div>

---

## 🚀 المزايا الرئيسية

### 1️⃣ التنبيهات الذكية (Smart Alerts)
- تحديث تلقائي لحالة المخزون كل 6 ساعات
- تصنيف تلقائي للأصناف القريبة من الانتهاء كـ "فائض"
- إشعارات للمخزون الحرج

### 2️⃣ سوق الفائض (Exchange Marketplace)
- واجهة سهلة لاستعراض الفائض المتاح
- فلترة حسب التصنيف والمدينة
- طلب نقل مباشر مع تتبع الحالة

### 3️⃣ لوحة التحليلات (Analytics Dashboard)
- إحصائيات شاملة عن المخزون
- تقارير الهدر المالي المُوفر
- رسوم بيانية تفاعلية

---

## 🛠️ التقنيات المستخدمة

### Backend
- **Node.js** - بيئة تشغيل JavaScript
- **Express.js** - إطار عمل الخادم
- **PostgreSQL** - قاعدة البيانات
- **Sequelize** - ORM للتعامل مع قاعدة البيانات
- **node-cron** - جدولة المهام التلقائية

### Frontend
- **React 18** - مكتبة واجهة المستخدم
- **Vite** - أداة البناء السريعة
- **Tailwind CSS** - إطار عمل التصميم
- **React Router** - التوجيه
- **Axios** - طلبات HTTP
- **Recharts** - الرسوم البيانية

---

## 📁 هيكلة المشروع

```
mawrid-platform/
├── backend/
│   ├── src/
│   │   ├── config/          # إعدادات قاعدة البيانات
│   │   ├── controllers/     # معالجات الطلبات
│   │   ├── models/          # نماذج قاعدة البيانات
│   │   ├── routes/          # مسارات API
│   │   ├── services/        # الخدمات (التنبيهات الذكية)
│   │   ├── middleware/      # Middleware
│   │   ├── utils/           # أدوات مساعدة (Cron Jobs)
│   │   └── server.js        # نقطة الدخول الرئيسية
│   ├── .env.example         # ملف البيئة النموذجي
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── components/      # المكونات القابلة لإعادة الاستخدام
    │   ├── pages/           # صفحات التطبيق
    │   ├── services/        # خدمات API
    │   ├── utils/           # أدوات مساعدة
    │   ├── App.jsx          # المكون الرئيسي
    │   └── main.jsx         # نقطة الدخول
    ├── index.html
    ├── vite.config.js
    ├── tailwind.config.js
    └── package.json
```

---

## 🗄️ هيكلة قاعدة البيانات

### الجداول الرئيسية

#### 1. health_centers (المراكز الصحية)
```sql
- id (UUID)
- name (String)
- name_ar (String)
- city (String)
- region (String)
- contact_info (JSON)
- manager_name (String)
- manager_email (String)
- is_active (Boolean)
```

#### 2. inventory (المخزون)
```sql
- id (UUID)
- center_id (UUID) → FK to health_centers
- item_name (String)
- item_name_ar (String)
- category (ENUM: medications, dental_supplies, etc.)
- batch_number (String)
- quantity (Integer)
- expiry_date (Date)
- status (ENUM: available, surplus, critical, expired)
- unit_price (Decimal)
```

#### 3. transfer_requests (طلبات النقل)
```sql
- id (UUID)
- item_id (UUID) → FK to inventory
- sender_center_id (UUID) → FK to health_centers
- receiver_center_id (UUID) → FK to health_centers
- quantity (Integer)
- status (ENUM: pending, approved, shipped, received)
- tracking_number (String)
- priority (ENUM: low, medium, high, urgent)
```

---

## 🚦 التثبيت والتشغيل

### المتطلبات الأساسية
- Node.js (v18 أو أحدث)
- PostgreSQL (v13 أو أحدث)
- npm أو yarn

### 1️⃣ تثبيت Backend

```bash
# الانتقال إلى مجلد Backend
cd backend

# تثبيت المكتبات
npm install

# نسخ ملف البيئة
cp .env.example .env

# تعديل ملف .env بإعدادات قاعدة البيانات الخاصة بك
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=mawrid_db
# DB_USER=postgres
# DB_PASSWORD=your_password

# تشغيل الخادم
npm run dev
```

الخادم سيعمل على: `http://localhost:5000`

### 2️⃣ تثبيت Frontend

```bash
# في نافذة طرفية جديدة
cd frontend

# تثبيت المكتبات
npm install

# تشغيل التطبيق
npm run dev
```

التطبيق سيعمل على: `http://localhost:3000`

---

## 🔧 إعداد قاعدة البيانات

### خيار 1: إنشاء قاعدة البيانات يدوياً

```bash
# تسجيل الدخول إلى PostgreSQL
psql -U postgres

# إنشاء قاعدة البيانات
CREATE DATABASE mawrid_db;

# الخروج
\q
```

### خيار 2: استخدام Sequelize

عند تشغيل Backend لأول مرة، سيتم إنشاء الجداول تلقائياً باستخدام Sequelize.

---

## 📡 API Endpoints

### المراكز الصحية
```
GET    /api/health-centers          # جلب جميع المراكز
GET    /api/health-centers/:id      # جلب مركز محدد
POST   /api/health-centers          # إنشاء مركز جديد
PUT    /api/health-centers/:id      # تحديث مركز
DELETE /api/health-centers/:id      # حذف مركز
GET    /api/health-centers/stats    # إحصائيات المراكز
```

### المخزون
```
GET    /api/inventory               # جلب المخزون
GET    /api/inventory/surplus       # جلب الفائض
GET    /api/inventory/:id           # جلب صنف محدد
POST   /api/inventory               # إضافة صنف جديد
PUT    /api/inventory/:id           # تحديث صنف
DELETE /api/inventory/:id           # حذف صنف
GET    /api/inventory/stats         # إحصائيات المخزون
```

### طلبات النقل
```
GET    /api/transfers               # جلب جميع الطلبات
GET    /api/transfers/:id           # جلب طلب محدد
POST   /api/transfers               # إنشاء طلب جديد
PATCH  /api/transfers/:id/status    # تحديث حالة الطلب
DELETE /api/transfers/:id           # حذف طلب
GET    /api/transfers/stats         # إحصائيات النقل
```

### التحليلات
```
GET    /api/analytics/dashboard           # لوحة التحكم الشاملة
GET    /api/analytics/waste-prevention    # تقرير الهدر المالي
GET    /api/analytics/center/:id          # تحليلات مركز محدد
```

---

## 🔄 نظام التنبيهات التلقائية

يعمل النظام على تحديث حالة المخزون تلقائياً من خلال Cron Jobs:

### المهام المجدولة:
1. **تحديث يومي**: كل يوم الساعة 2:00 صباحاً
   - تحديث حالة الأصناف إلى "فائض" (expiring within 90 days)
   - تحديث حالة الأصناف إلى "منتهي" (past expiry date)
   - تحديث حالة الأصناف إلى "حرج" (low quantity)

2. **فحص دوري**: كل 6 ساعات
   - فحص المخزون الحرج
   - إرسال تنبيهات (يمكن إضافة إشعارات بريدية)

---

## 🎨 لقطات الشاشة

### لوحة التحكم الرئيسية
- إحصائيات شاملة
- الهدر المالي المُوفر
- رسوم بيانية تفاعلية

### سوق الفائض
- بطاقات الأصناف المتاحة
- نموذج طلب النقل
- فلترة متقدمة

### إدارة المخزون
- جدول شامل بالمخزون
- إضافة وتعديل الأصناف
- تتبع تواريخ الانتهاء

---

## 🔐 الأمان

### في الإنتاج، تأكد من:
1. ✅ استخدام متغيرات البيئة لحماية البيانات الحساسة
2. ✅ تفعيل HTTPS
3. ✅ إضافة نظام مصادقة (JWT)
4. ✅ تفعيل Rate Limiting
5. ✅ فلترة البيانات المدخلة
6. ✅ استخدام Helmet.js للحماية

---

## 🚀 النشر (Deployment)

### Backend
يمكن نشر Backend على:
- **Railway**
- **Render**
- **Heroku**
- **AWS EC2**
- **DigitalOcean**

### Frontend
يمكن نشر Frontend على:
- **Vercel**
- **Netlify**
- **GitHub Pages**
- **AWS S3 + CloudFront**

### قاعدة البيانات
- **ElephantSQL** (PostgreSQL managed)
- **Supabase**
- **AWS RDS**
- **DigitalOcean Managed Databases**

---

## 📈 التطوير المستقبلي

### مقترحات التحسين:
- [ ] نظام مصادقة متكامل (Authentication & Authorization)
- [ ] إشعارات البريد الإلكتروني للتنبيهات
- [ ] تطبيق موبايل (React Native)
- [ ] تقارير PDF قابلة للتصدير
- [ ] نظام رسائل داخلي بين المراكز
- [ ] دعم اللغة الإنجليزية
- [ ] نظام تقييم للمراكز
- [ ] تكامل مع أنظمة ERP الموجودة

---

## 👥 المساهمة

نرحب بالمساهمات! يرجى:
1. عمل Fork للمشروع
2. إنشاء Feature Branch
3. Commit التعديلات
4. Push إلى Branch
5. فتح Pull Request

---

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف LICENSE للتفاصيل.

---

## 📞 التواصل

لأي استفسارات أو اقتراحات:
- **البريد الإلكتروني**: support@mawrid.sa
- **الموقع**: www.mawrid.sa

---

## ⭐ شكر وتقدير

شكراً لاستخدامكم منصة مورد! نتطلع لمساهماتكم في تحسين القطاع الصحي.

**صُنع بـ ❤️ في المملكة العربية السعودية**

</div>
