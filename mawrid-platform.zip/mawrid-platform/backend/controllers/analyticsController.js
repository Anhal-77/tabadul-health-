const { HealthCenter, Inventory, TransferRequest, sequelize } = require('../models');
const { Op } = require('sequelize');

// Get dashboard analytics
const getDashboardAnalytics = async (req, res) => {
  try {
    const { center_id, start_date, end_date } = req.query;

    // Total centers
    const totalCenters = await HealthCenter.count({
      where: { is_active: true }
    });

    // Total inventory items
    const totalInventory = await Inventory.count();

    // Surplus items count
    const surplusCount = await Inventory.count({
      where: { status: 'surplus' }
    });

    // Critical items count
    const criticalCount = await Inventory.count({
      where: { status: 'critical' }
    });

    // Transfer requests statistics
    const transferStats = await TransferRequest.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count']
      ],
      group: ['status']
    });

    // Calculate waste avoided
    const completedTransfers = await TransferRequest.findAll({
      where: {
        status: 'received'
      },
      include: [{
        model: Inventory,
        as: 'item',
        attributes: ['unit_price']
      }]
    });

    const wasteAvoided = completedTransfers.reduce((total, transfer) => {
      const value = (transfer.item?.unit_price || 0) * transfer.quantity;
      return total + parseFloat(value);
    }, 0);

    // Items by category
    const itemsByCategory = await Inventory.findAll({
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity']
      ],
      group: ['category']
    });

    // Recent activity
    const recentTransfers = await TransferRequest.findAll({
      limit: 5,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Inventory,
          as: 'item',
          attributes: ['item_name', 'category']
        },
        {
          model: HealthCenter,
          as: 'senderCenter',
          attributes: ['name', 'city']
        },
        {
          model: HealthCenter,
          as: 'receiverCenter',
          attributes: ['name', 'city']
        }
      ]
    });

    res.json({
      success: true,
      data: {
        overview: {
          total_centers: totalCenters,
          total_inventory_items: totalInventory,
          surplus_items: surplusCount,
          critical_items: criticalCount,
          waste_avoided_value: wasteAvoided.toFixed(2)
        },
        transfer_statistics: transferStats,
        items_by_category: itemsByCategory,
        recent_activity: recentTransfers
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching analytics',
      error: error.message
    });
  }
};

// Get waste reduction statistics
const getWasteReductionStats = async (req, res) => {
  try {
    // Items saved from expiry (transferred before expiring)
    const today = new Date();
    
    const savedItems = await TransferRequest.findAll({
      where: {
        status: 'received'
      },
      include: [{
        model: Inventory,
        as: 'item',
        where: {
          expiry_date: {
            [Op.gte]: today
          }
        },
        attributes: ['item_name', 'expiry_date', 'unit_price']
      }]
    });

    const totalValueSaved = savedItems.reduce((total, transfer) => {
      const value = (transfer.item?.unit_price || 0) * transfer.quantity;
      return total + parseFloat(value);
    }, 0);

    const totalItemsSaved = savedItems.reduce((total, transfer) => {
      return total + transfer.quantity;
    }, 0);

    // Expired items (waste)
    const expiredItems = await Inventory.findAll({
      where: {
        status: 'expired'
      }
    });

    const totalWaste = expiredItems.reduce((total, item) => {
      const value = (item.unit_price || 0) * item.quantity;
      return total + parseFloat(value);
    }, 0);

    res.json({
      success: true,
      data: {
        items_saved: totalItemsSaved,
        value_saved: totalValueSaved.toFixed(2),
        expired_items_count: expiredItems.length,
        waste_value: totalWaste.toFixed(2),
        waste_reduction_percentage: totalWaste > 0 
          ? ((totalValueSaved / (totalValueSaved + totalWaste)) * 100).toFixed(2)
          : 100
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching waste reduction statistics',
      error: error.message
    });
  }
};

// Get center-specific statistics
const getCenterStatistics = async (req, res) => {
  try {
    const { center_id } = req.params;

    const center = await HealthCenter.findByPk(center_id);
    
    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'Health center not found'
      });
    }

    // Inventory statistics
    const inventoryStats = await Inventory.findAll({
      where: { center_id },
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity']
      ],
      group: ['status']
    });

    // Sent requests
    const sentRequests = await TransferRequest.count({
      where: { sender_center_id: center_id }
    });

    // Received requests
    const receivedRequests = await TransferRequest.count({
      where: { receiver_center_id: center_id }
    });

    res.json({
      success: true,
      data: {
        center_info: center,
        inventory_statistics: inventoryStats,
        transfer_summary: {
          sent_requests: sentRequests,
          received_requests: receivedRequests
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching center statistics',
      error: error.message
    });
  }
};

module.exports = {
  getDashboardAnalytics,
  getWasteReductionStats,
  getCenterStatistics
};
