const { Inventory, HealthCenter } = require('../models');
const { Op } = require('sequelize');

// Get all inventory items with filters
const getAllInventory = async (req, res) => {
  try {
    const { center_id, category, status, search } = req.query;
    
    const whereClause = {};
    if (center_id) whereClause.center_id = center_id;
    if (category) whereClause.category = category;
    if (status) whereClause.status = status;
    if (search) {
      whereClause.item_name = { [Op.iLike]: `%${search}%` };
    }

    const inventory = await Inventory.findAll({
      where: whereClause,
      include: [{
        model: HealthCenter,
        as: 'center',
        attributes: ['id', 'name', 'city']
      }],
      order: [['expiry_date', 'ASC']]
    });

    res.json({
      success: true,
      count: inventory.length,
      data: inventory
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching inventory',
      error: error.message
    });
  }
};

// Get surplus items (items expiring within 90 days)
const getSurplusItems = async (req, res) => {
  try {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + (parseInt(process.env.EXPIRY_ALERT_DAYS) || 90));

    const surplusItems = await Inventory.findAll({
      where: {
        status: 'surplus',
        expiry_date: {
          [Op.between]: [today, futureDate]
        },
        quantity: {
          [Op.gt]: 0
        }
      },
      include: [{
        model: HealthCenter,
        as: 'center',
        attributes: ['id', 'name', 'city', 'contact_info']
      }],
      order: [['expiry_date', 'ASC']]
    });

    // Calculate days until expiry for each item
    const itemsWithDaysLeft = surplusItems.map(item => {
      const daysLeft = Math.ceil((new Date(item.expiry_date) - today) / (1000 * 60 * 60 * 24));
      return {
        ...item.toJSON(),
        days_until_expiry: daysLeft
      };
    });

    res.json({
      success: true,
      count: itemsWithDaysLeft.length,
      data: itemsWithDaysLeft
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching surplus items',
      error: error.message
    });
  }
};

// Get critical items (low quantity)
const getCriticalItems = async (req, res) => {
  try {
    const criticalItems = await Inventory.findAll({
      where: {
        status: 'critical'
      },
      include: [{
        model: HealthCenter,
        as: 'center',
        attributes: ['id', 'name', 'city']
      }],
      order: [['quantity', 'ASC']]
    });

    res.json({
      success: true,
      count: criticalItems.length,
      data: criticalItems
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching critical items',
      error: error.message
    });
  }
};

// Get single inventory item
const getInventoryById = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id, {
      include: [{
        model: HealthCenter,
        as: 'center'
      }]
    });

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Inventory item not found'
      });
    }

    res.json({
      success: true,
      data: item
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching inventory item',
      error: error.message
    });
  }
};

// Create new inventory item
const createInventoryItem = async (req, res) => {
  try {
    const {
      center_id,
      item_name,
      category,
      batch_number,
      quantity,
      expiry_date,
      unit_price,
      description
    } = req.body;

    const item = await Inventory.create({
      center_id,
      item_name,
      category,
      batch_number,
      quantity,
      expiry_date,
      unit_price,
      description
    });

    res.status(201).json({
      success: true,
      message: 'Inventory item created successfully',
      data: item
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error creating inventory item',
      error: error.message
    });
  }
};

// Update inventory item
const updateInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Inventory item not found'
      });
    }

    await item.update(req.body);

    res.json({
      success: true,
      message: 'Inventory item updated successfully',
      data: item
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Error updating inventory item',
      error: error.message
    });
  }
};

// Delete inventory item
const deleteInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'Inventory item not found'
      });
    }

    await item.destroy();

    res.json({
      success: true,
      message: 'Inventory item deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting inventory item',
      error: error.message
    });
  }
};

module.exports = {
  getAllInventory,
  getSurplusItems,
  getCriticalItems,
  getInventoryById,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem
};
