const { TransferRequest, Inventory, HealthCenter, sequelize } = require('../models');
const { Op } = require('sequelize');

// Get all transfer requests with filters
const getAllTransferRequests = async (req, res) => {
  try {
    const { sender_id, receiver_id, status } = req.query;
    
    const whereClause = {};
    if (sender_id) whereClause.sender_center_id = sender_id;
    if (receiver_id) whereClause.receiver_center_id = receiver_id;
    if (status) whereClause.status = status;

    const requests = await TransferRequest.findAll({
      where: whereClause,
      include: [
        {
          model: Inventory,
          as: 'item',
          attributes: ['id', 'item_name', 'category', 'expiry_date', 'quantity']
        },
        {
          model: HealthCenter,
          as: 'senderCenter',
          attributes: ['id', 'name', 'city']
        },
        {
          model: HealthCenter,
          as: 'receiverCenter',
          attributes: ['id', 'name', 'city']
        }
      ],
      order: [['created_at', 'DESC']]
    });

    res.json({
      success: true,
      count: requests.length,
      data: requests
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching transfer requests',
      error: error.message
    });
  }
};

// Get single transfer request
const getTransferRequestById = async (req, res) => {
  try {
    const request = await TransferRequest.findByPk(req.params.id, {
      include: [
        {
          model: Inventory,
          as: 'item',
          include: [{
            model: HealthCenter,
            as: 'center'
          }]
        },
        {
          model: HealthCenter,
          as: 'senderCenter'
        },
        {
          model: HealthCenter,
          as: 'receiverCenter'
        }
      ]
    });

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'Transfer request not found'
      });
    }

    res.json({
      success: true,
      data: request
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching transfer request',
      error: error.message
    });
  }
};

// Create new transfer request
const createTransferRequest = async (req, res) => {
  const transaction = await sequelize.transaction();
  
  try {
    const {
      item_id,
      sender_center_id,
      receiver_center_id,
      quantity,
      request_notes
    } = req.body;

    // Validate item exists and has enough quantity
    const item = await Inventory.findByPk(item_id);
    
    if (!item) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Inventory item not found'
      });
    }

    if (item.quantity < quantity) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Insufficient quantity. Available: ${item.quantity}, Requested: ${quantity}`
      });
    }

    if (item.center_id !== sender_center_id) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Item does not belong to sender center'
      });
    }

    const request = await TransferRequest.create({
      item_id,
      sender_center_id,
      receiver_center_id,
      quantity,
      request_notes,
      requested_at: new Date()
    }, { transaction });

    await transaction.commit();

    const fullRequest = await TransferRequest.findByPk(request.id, {
      include: [
        { model: Inventory, as: 'item' },
        { model: HealthCenter, as: 'senderCenter' },
        { model: HealthCenter, as: 'receiverCenter' }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'Transfer request created successfully',
      data: fullRequest
    });
  } catch (error) {
    await transaction.rollback();
    res.status(400).json({
      success: false,
      message: 'Error creating transfer request',
      error: error.message
    });
  }
};

// Update transfer request status
const updateTransferStatus = async (req, res) => {
  const transaction = await sequelize.transaction();
  
  try {
    const { status, response_notes } = req.body;
    
    const request = await TransferRequest.findByPk(req.params.id, {
      include: [{ model: Inventory, as: 'item' }]
    });

    if (!request) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Transfer request not found'
      });
    }

    const updateData = { status, response_notes };

    // Set timestamps based on status
    if (status === 'approved') {
      updateData.approved_at = new Date();
    } else if (status === 'shipped') {
      updateData.shipped_at = new Date();
    } else if (status === 'received') {
      updateData.received_at = new Date();
      
      // Deduct quantity from sender's inventory
      const item = await Inventory.findByPk(request.item_id);
      await item.update({
        quantity: item.quantity - request.quantity
      }, { transaction });
    }

    await request.update(updateData, { transaction });
    await transaction.commit();

    const updatedRequest = await TransferRequest.findByPk(request.id, {
      include: [
        { model: Inventory, as: 'item' },
        { model: HealthCenter, as: 'senderCenter' },
        { model: HealthCenter, as: 'receiverCenter' }
      ]
    });

    res.json({
      success: true,
      message: `Transfer request ${status} successfully`,
      data: updatedRequest
    });
  } catch (error) {
    await transaction.rollback();
    res.status(400).json({
      success: false,
      message: 'Error updating transfer request',
      error: error.message
    });
  }
};

// Delete/Cancel transfer request
const deleteTransferRequest = async (req, res) => {
  try {
    const request = await TransferRequest.findByPk(req.params.id);

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'Transfer request not found'
      });
    }

    if (request.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Only pending requests can be cancelled'
      });
    }

    await request.update({ status: 'cancelled' });

    res.json({
      success: true,
      message: 'Transfer request cancelled successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error cancelling transfer request',
      error: error.message
    });
  }
};

module.exports = {
  getAllTransferRequests,
  getTransferRequestById,
  createTransferRequest,
  updateTransferStatus,
  deleteTransferRequest
};
