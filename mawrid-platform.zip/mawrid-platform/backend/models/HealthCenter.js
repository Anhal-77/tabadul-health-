const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const HealthCenter = sequelize.define('HealthCenter', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [3, 255]
    }
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  contact_info: {
    type: DataTypes.JSONB,
    allowNull: true,
    defaultValue: {},
    comment: 'Stores phone, email, address in JSON format'
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'health_centers',
  indexes: [
    {
      fields: ['city']
    },
    {
      fields: ['is_active']
    }
  ]
});

module.exports = HealthCenter;
