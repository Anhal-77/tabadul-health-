const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const TransferRequest = sequelize.define('TransferRequest', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  item_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'inventory',
      key: 'id'
    },
    onDelete: 'CASCADE'
  },
  sender_center_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    }
  },
  receiver_center_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'health_centers',
      key: 'id'
    }
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1
    }
  },
  status: {
    type: DataTypes.ENUM('pending', 'approved', 'rejected', 'shipped', 'received', 'cancelled'),
    allowNull: false,
    defaultValue: 'pending'
  },
  request_notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  response_notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  requested_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  approved_at: {
    type: DataTypes.DATE,
    allowNull: true
  },
  shipped_at: {
    type: DataTypes.DATE,
    allowNull: true
  },
  received_at: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'transfer_requests',
  indexes: [
    {
      fields: ['item_id']
    },
    {
      fields: ['sender_center_id']
    },
    {
      fields: ['receiver_center_id']
    },
    {
      fields: ['status']
    }
  ],
  validate: {
    differentCenters() {
      if (this.sender_center_id === this.receiver_center_id) {
        throw new Error('Sender and receiver centers must be different');
      }
    }
  }
});

module.exports = TransferRequest;
