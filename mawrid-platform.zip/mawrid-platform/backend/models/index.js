const { sequelize } = require('../config/database');
const HealthCenter = require('./HealthCenter');
const Inventory = require('./Inventory');
const TransferRequest = require('./TransferRequest');

// Define Associations

// HealthCenter has many Inventory items
HealthCenter.hasMany(Inventory, {
  foreignKey: 'center_id',
  as: 'inventory'
});
Inventory.belongsTo(HealthCenter, {
  foreignKey: 'center_id',
  as: 'center'
});

// TransferRequest belongs to Inventory
TransferRequest.belongsTo(Inventory, {
  foreignKey: 'item_id',
  as: 'item'
});
Inventory.hasMany(TransferRequest, {
  foreignKey: 'item_id',
  as: 'transferRequests'
});

// TransferRequest belongs to sender and receiver centers
TransferRequest.belongsTo(HealthCenter, {
  foreignKey: 'sender_center_id',
  as: 'senderCenter'
});
TransferRequest.belongsTo(HealthCenter, {
  foreignKey: 'receiver_center_id',
  as: 'receiverCenter'
});

HealthCenter.hasMany(TransferRequest, {
  foreignKey: 'sender_center_id',
  as: 'sentRequests'
});
HealthCenter.hasMany(TransferRequest, {
  foreignKey: 'receiver_center_id',
  as: 'receivedRequests'
});

// Sync database
const syncDatabase = async (force = false) => {
  try {
    await sequelize.sync({ force });
    console.log('✅ Database synchronized successfully');
  } catch (error) {
    console.error('❌ Database sync error:', error);
    throw error;
  }
};

module.exports = {
  sequelize,
  HealthCenter,
  Inventory,
  TransferRequest,
  syncDatabase
};
