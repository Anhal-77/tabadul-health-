require('dotenv').config();
const { sequelize } = require('./database');
const { HealthCenter, Inventory, TransferRequest } = require('../models');

const initializeDatabase = async () => {
  try {
    console.log('🔄 Initializing database...');

    // Force sync (drops existing tables and recreates them)
    await sequelize.sync({ force: true });
    console.log('✅ Database tables created');

    // Create sample health centers
    const centers = await HealthCenter.bulkCreate([
      {
        name: 'مركز الملك فهد الصحي',
        city: 'الرياض',
        contact_info: {
          phone: '+966112345678',
          email: 'kingfahd@health.gov.sa',
          address: 'حي الملز، الرياض'
        }
      },
      {
        name: 'مركز الأمير سلمان الصحي',
        city: 'جدة',
        contact_info: {
          phone: '+966126543210',
          email: 'salman@health.gov.sa',
          address: 'حي الروضة، جدة'
        }
      },
      {
        name: 'مركز الملكة رانيا الصحي',
        city: 'الدمام',
        contact_info: {
          phone: '+966138765432',
          email: 'rania@health.gov.sa',
          address: 'حي الفيصلية، الدمام'
        }
      },
      {
        name: 'مركز الأمير عبدالعزيز الصحي',
        city: 'مكة المكرمة',
        contact_info: {
          phone: '+966125678901',
          email: 'abdulaziz@health.gov.sa',
          address: 'حي العزيزية، مكة المكرمة'
        }
      }
    ]);
    console.log(`✅ Created ${centers.length} health centers`);

    // Create sample inventory items
    const today = new Date();
    const inventoryData = [];

    // Center 1 - has surplus dental tools
    inventoryData.push(
      {
        center_id: centers[0].id,
        item_name: 'أدوات حشو الأسنان - طقم كامل',
        category: 'dental_tools',
        batch_number: 'DT-2024-001',
        quantity: 50,
        expiry_date: new Date(today.getTime() + 60 * 24 * 60 * 60 * 1000), // 60 days
        minimum_threshold: 10
      },
      {
        center_id: centers[0].id,
        item_name: 'باراسيتامول 500mg',
        category: 'medication',
        batch_number: 'MED-2024-101',
        quantity: 200,
        expiry_date: new Date(today.getTime() + 45 * 24 * 60 * 60 * 1000), // 45 days
        minimum_threshold: 20
      },
      {
        center_id: centers[0].id,
        item_name: 'قفازات طبية مقاس M',
        category: 'medical_supplies',
        batch_number: 'SUP-2024-201',
        quantity: 150,
        expiry_date: new Date(today.getTime() + 180 * 24 * 60 * 60 * 1000), // 180 days
        minimum_threshold: 30
      }
    );

    // Center 2 - has surplus medications
    inventoryData.push(
      {
        center_id: centers[1].id,
        item_name: 'أيبوبروفين 400mg',
        category: 'medication',
        batch_number: 'MED-2024-102',
        quantity: 300,
        expiry_date: new Date(today.getTime() + 75 * 24 * 60 * 60 * 1000), // 75 days
        minimum_threshold: 50
      },
      {
        center_id: centers[1].id,
        item_name: 'مرايا أسنان معقمة',
        category: 'dental_tools',
        batch_number: 'DT-2024-002',
        quantity: 80,
        expiry_date: new Date(today.getTime() + 50 * 24 * 60 * 60 * 1000), // 50 days
        minimum_threshold: 15
      }
    );

    // Center 3 - has critical items (low stock)
    inventoryData.push(
      {
        center_id: centers[2].id,
        item_name: 'شاش طبي معقم',
        category: 'medical_supplies',
        batch_number: 'SUP-2024-202',
        quantity: 8, // Below threshold
        expiry_date: new Date(today.getTime() + 120 * 24 * 60 * 60 * 1000),
        minimum_threshold: 10
      },
      {
        center_id: centers[2].id,
        item_name: 'أمبيسيلين 250mg',
        category: 'medication',
        batch_number: 'MED-2024-103',
        quantity: 100,
        expiry_date: new Date(today.getTime() + 200 * 24 * 60 * 60 * 1000),
        minimum_threshold: 20
      }
    );

    // Center 4 - mixed inventory
    inventoryData.push(
      {
        center_id: centers[3].id,
        item_name: 'مخدر موضعي للأسنان',
        category: 'medication',
        batch_number: 'MED-2024-104',
        quantity: 60,
        expiry_date: new Date(today.getTime() + 85 * 24 * 60 * 60 * 1000), // 85 days
        minimum_threshold: 15
      },
      {
        center_id: centers[3].id,
        item_name: 'كمامات N95',
        category: 'medical_supplies',
        batch_number: 'SUP-2024-203',
        quantity: 500,
        expiry_date: new Date(today.getTime() + 300 * 24 * 60 * 60 * 1000),
        minimum_threshold: 100
      }
    );

    const inventory = await Inventory.bulkCreate(inventoryData);
    console.log(`✅ Created ${inventory.length} inventory items`);

    // Create sample transfer request
    const transfer = await TransferRequest.create({
      item_id: inventory[0].id, // Dental tools from center 1
      sender_center_id: centers[0].id,
      receiver_center_id: centers[2].id,
      quantity: 20,
      status: 'pending',
      notes: 'طلب عاجل لأدوات حشو الأسنان'
    });
    console.log('✅ Created sample transfer request');

    console.log(`
╔════════════════════════════════════════╗
║   ✅ Database Initialized Successfully ║
╚════════════════════════════════════════╝

Summary:
- Health Centers: ${centers.length}
- Inventory Items: ${inventory.length}
- Transfer Requests: 1

You can now start the server with: npm run dev
    `);

    process.exit(0);
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    process.exit(1);
  }
};

initializeDatabase();
