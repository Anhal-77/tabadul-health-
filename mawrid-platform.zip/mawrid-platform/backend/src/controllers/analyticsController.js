const alertService = require('../services/alertService');
const { HealthCenter, Inventory, TransferRequest } = require('../models');
const { Op } = require('sequelize');

/**
 * Get comprehensive analytics dashboard data
 */
exports.getDashboardAnalytics = async (req, res) => {
  try {
    const { sequelize } = require('../config/database');

    // 1. Overall Statistics
    const totalCenters = await HealthCenter.count({ where: { is_active: true } });
    const totalInventoryItems = await Inventory.count();
    const totalTransferRequests = await TransferRequest.count();

    // 2. Waste Prevention Analytics
    const wastePrevention = await alertService.getWastePrevention();

    // 3. Surplus Items Count by Category
    const surplusByCategory = await Inventory.findAll({
      where: { status: 'surplus' },
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('total_value')), 'total_value']
      ],
      group: ['category'],
      raw: true
    });

    // 4. Transfer Requests Status Distribution
    const transfersByStatus = await TransferRequest.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count']
      ],
      group: ['status'],
      raw: true
    });

    // 5. Items Expiring Soon (next 30 days)
    const today = new Date();
    const next30Days = new Date();
    next30Days.setDate(today.getDate() + 30);

    const expiringSoon = await Inventory.count({
      where: {
        expiry_date: {
          [Op.between]: [today, next30Days]
        },
        quantity: {
          [Op.gt]: 0
        }
      }
    });

    // 6. Top Active Centers (by transfer activity)
    const topSenderCenters = await TransferRequest.findAll({
      attributes: [
        'sender_center_id',
        [sequelize.fn('COUNT', sequelize.col('id')), 'transfer_count']
      ],
      include: [{
        model: HealthCenter,
        as: 'sender_center',
        attributes: ['name', 'name_ar', 'city']
      }],
      group: ['sender_center_id', 'sender_center.id'],
      order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
      limit: 5,
      raw: true
    });

    // 7. Monthly Transfer Trends (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyTransfers = await TransferRequest.findAll({
      attributes: [
        [sequelize.fn('DATE_TRUNC', 'month', sequelize.col('request_date')), 'month'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('estimated_value')), 'total_value']
      ],
      where: {
        request_date: {
          [Op.gte]: sixMonthsAgo
        }
      },
      group: [sequelize.fn('DATE_TRUNC', 'month', sequelize.col('request_date'))],
      order: [[sequelize.fn('DATE_TRUNC', 'month', sequelize.col('request_date')), 'ASC']],
      raw: true
    });

    // 8. Critical Stock Items
    const criticalStock = await Inventory.count({
      where: { status: 'critical' }
    });

    // 9. Category Distribution
    const categoryDistribution = await Inventory.findAll({
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity']
      ],
      group: ['category'],
      raw: true
    });

    res.status(200).json({
      success: true,
      data: {
        overview: {
          total_centers: totalCenters,
          total_inventory_items: totalInventoryItems,
          total_transfer_requests: totalTransferRequests,
          items_expiring_soon: expiringSoon,
          critical_stock_items: criticalStock
        },
        waste_prevention: wastePrevention,
        surplus_by_category: surplusByCategory,
        transfers_by_status: transfersByStatus,
        top_sender_centers: topSenderCenters,
        monthly_trends: monthlyTransfers,
        category_distribution: categoryDistribution
      }
    });
  } catch (error) {
    console.error('Error fetching dashboard analytics:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب بيانات لوحة التحكم',
      error: error.message
    });
  }
};

/**
 * Get waste prevention report
 */
exports.getWastePreventionReport = async (req, res) => {
  try {
    const report = await alertService.getWastePrevention();

    res.status(200).json({
      success: true,
      data: report
    });
  } catch (error) {
    console.error('Error fetching waste prevention report:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب تقرير الهدر المالي',
      error: error.message
    });
  }
};

/**
 * Get center-specific analytics
 */
exports.getCenterAnalytics = async (req, res) => {
  try {
    const { center_id } = req.params;
    const { sequelize } = require('../config/database');

    // Verify center exists
    const center = await HealthCenter.findByPk(center_id);
    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'المركز الصحي غير موجود'
      });
    }

    // 1. Inventory Summary
    const inventorySummary = await Inventory.findAll({
      where: { center_id },
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('total_value')), 'total_value']
      ],
      group: ['status'],
      raw: true
    });

    // 2. Category Breakdown
    const categoryBreakdown = await Inventory.findAll({
      where: { center_id },
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity']
      ],
      group: ['category'],
      raw: true
    });

    // 3. Transfer Activity
    const sentRequests = await TransferRequest.count({
      where: { sender_center_id: center_id }
    });

    const receivedRequests = await TransferRequest.count({
      where: { receiver_center_id: center_id }
    });

    // 4. Items Expiring Soon
    const expiringItems = await alertService.getExpiringItemsByCenter(center_id);

    res.status(200).json({
      success: true,
      data: {
        center_info: center,
        inventory_summary: inventorySummary,
        category_breakdown: categoryBreakdown,
        transfer_activity: {
          sent_requests: sentRequests,
          received_requests: receivedRequests
        },
        expiring_items_count: expiringItems.length,
        expiring_items: expiringItems.slice(0, 10) // Top 10 items
      }
    });
  } catch (error) {
    console.error('Error fetching center analytics:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب تحليلات المركز',
      error: error.message
    });
  }
};
