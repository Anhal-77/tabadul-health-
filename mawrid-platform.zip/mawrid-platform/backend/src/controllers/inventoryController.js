const { Inventory, HealthCenter } = require('../models');
const { Op } = require('sequelize');
const alertService = require('../services/alertService');

/**
 * Get all inventory items
 */
exports.getAllInventory = async (req, res) => {
  try {
    const { 
      center_id, 
      category, 
      status, 
      search,
      page = 1,
      limit = 50
    } = req.query;

    const whereClause = {};
    
    if (center_id) whereClause.center_id = center_id;
    if (category) whereClause.category = category;
    if (status) whereClause.status = status;
    if (search) {
      whereClause[Op.or] = [
        { item_name: { [Op.iLike]: `%${search}%` } },
        { item_name_ar: { [Op.iLike]: `%${search}%` } },
        { batch_number: { [Op.iLike]: `%${search}%` } }
      ];
    }

    const offset = (page - 1) * limit;

    const { count, rows: items } = await Inventory.findAndCountAll({
      where: whereClause,
      include: [{
        model: HealthCenter,
        as: 'health_center',
        attributes: ['id', 'name', 'name_ar', 'city']
      }],
      limit: parseInt(limit),
      offset: offset,
      order: [['expiry_date', 'ASC']]
    });

    res.status(200).json({
      success: true,
      count: count,
      total_pages: Math.ceil(count / limit),
      current_page: parseInt(page),
      data: items
    });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب المخزون',
      error: error.message
    });
  }
};

/**
 * Get single inventory item
 */
exports.getInventoryById = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id, {
      include: [{
        model: HealthCenter,
        as: 'health_center'
      }]
    });

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'الصنف غير موجود'
      });
    }

    res.status(200).json({
      success: true,
      data: item
    });
  } catch (error) {
    console.error('Error fetching item:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الصنف',
      error: error.message
    });
  }
};

/**
 * Create new inventory item
 */
exports.createInventory = async (req, res) => {
  try {
    const {
      center_id,
      item_name,
      item_name_ar,
      category,
      batch_number,
      quantity,
      unit,
      expiry_date,
      unit_price,
      manufacturer,
      storage_location,
      notes
    } = req.body;

    // Verify health center exists
    const center = await HealthCenter.findByPk(center_id);
    if (!center) {
      return res.status(404).json({
        success: false,
        message: 'المركز الصحي غير موجود'
      });
    }

    const item = await Inventory.create({
      center_id,
      item_name,
      item_name_ar,
      category,
      batch_number,
      quantity,
      unit,
      expiry_date,
      unit_price,
      manufacturer,
      storage_location,
      notes,
      status: 'available'
    });

    // Trigger alert service to update status
    await alertService.updateInventoryStatus();

    res.status(201).json({
      success: true,
      message: 'تم إضافة الصنف بنجاح',
      data: item
    });
  } catch (error) {
    console.error('Error creating inventory:', error);
    
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({
        success: false,
        message: 'رقم الدفعة موجود مسبقاً في هذا المركز'
      });
    }

    res.status(500).json({
      success: false,
      message: 'خطأ في إضافة الصنف',
      error: error.message
    });
  }
};

/**
 * Update inventory item
 */
exports.updateInventory = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'الصنف غير موجود'
      });
    }

    await item.update(req.body);

    res.status(200).json({
      success: true,
      message: 'تم تحديث الصنف بنجاح',
      data: item
    });
  } catch (error) {
    console.error('Error updating inventory:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث الصنف',
      error: error.message
    });
  }
};

/**
 * Delete inventory item
 */
exports.deleteInventory = async (req, res) => {
  try {
    const item = await Inventory.findByPk(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: 'الصنف غير موجود'
      });
    }

    await item.destroy();

    res.status(200).json({
      success: true,
      message: 'تم حذف الصنف بنجاح'
    });
  } catch (error) {
    console.error('Error deleting inventory:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في حذف الصنف',
      error: error.message
    });
  }
};

/**
 * Get surplus items (marketplace)
 */
exports.getSurplusItems = async (req, res) => {
  try {
    const { category, city } = req.query;
    
    const filters = {};
    if (category) filters.category = category;
    if (city) filters.city = city;

    const surplusItems = await alertService.getSurplusItems(filters);

    res.status(200).json({
      success: true,
      count: surplusItems.length,
      data: surplusItems
    });
  } catch (error) {
    console.error('Error fetching surplus items:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الفائض',
      error: error.message
    });
  }
};

/**
 * Get inventory statistics
 */
exports.getInventoryStats = async (req, res) => {
  try {
    const { sequelize } = require('../config/database');
    
    const totalItems = await Inventory.count();
    
    const itemsByStatus = await Inventory.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('total_value')), 'total_value']
      ],
      group: ['status'],
      raw: true
    });

    const itemsByCategory = await Inventory.findAll({
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity']
      ],
      group: ['category'],
      raw: true
    });

    res.status(200).json({
      success: true,
      data: {
        total_items: totalItems,
        items_by_status: itemsByStatus,
        items_by_category: itemsByCategory
      }
    });
  } catch (error) {
    console.error('Error fetching inventory stats:', error);
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب إحصائيات المخزون',
      error: error.message
    });
  }
};
