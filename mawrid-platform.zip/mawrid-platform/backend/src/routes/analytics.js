const express = require('express');
const router = express.Router();
const analyticsController = require('../controllers/analyticsController');

// GET /api/analytics/dashboard - Get dashboard statistics
router.get('/dashboard', analyticsController.getDashboardStats);

// GET /api/analytics/surplus-trends - Get surplus trends over time
router.get('/surplus-trends', analyticsController.getSurplusTrends);

// GET /api/analytics/category-distribution - Get category distribution
router.get('/category-distribution', analyticsController.getCategoryDistribution);

// GET /api/analytics/top-centers - Get top contributing centers
router.get('/top-centers', analyticsController.getTopCenters);

// GET /api/analytics/expiring-items - Get expiring items alert
router.get('/expiring-items', analyticsController.getExpiringItems);

module.exports = router;
