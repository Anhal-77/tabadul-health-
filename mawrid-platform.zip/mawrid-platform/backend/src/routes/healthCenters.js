const express = require('express');
const router = express.Router();
const healthCenterController = require('../controllers/healthCenterController');

// GET /api/health-centers - Get all health centers
router.get('/', healthCenterController.getAll);

// GET /api/health-centers/:id - Get single health center
router.get('/:id', healthCenterController.getById);

// POST /api/health-centers - Create new health center
router.post('/', healthCenterController.create);

// PUT /api/health-centers/:id - Update health center
router.put('/:id', healthCenterController.update);

// DELETE /api/health-centers/:id - Delete health center
router.delete('/:id', healthCenterController.delete);

module.exports = router;
