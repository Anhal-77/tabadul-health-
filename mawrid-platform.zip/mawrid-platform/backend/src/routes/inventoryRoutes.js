const express = require('express');
const router = express.Router();
const {
  getAllInventory,
  getInventoryById,
  createInventory,
  updateInventory,
  deleteInventory,
  getSurplusItems,
  getInventoryStats
} = require('../controllers/inventoryController');

/**
 * @route   GET /api/inventory
 * @desc    Get all inventory items
 * @access  Public
 */
router.get('/', getAllInventory);

/**
 * @route   GET /api/inventory/surplus
 * @desc    Get surplus items (marketplace)
 * @access  Public
 */
router.get('/surplus', getSurplusItems);

/**
 * @route   GET /api/inventory/stats
 * @desc    Get inventory statistics
 * @access  Public
 */
router.get('/stats', getInventoryStats);

/**
 * @route   GET /api/inventory/:id
 * @desc    Get single inventory item
 * @access  Public
 */
router.get('/:id', getInventoryById);

/**
 * @route   POST /api/inventory
 * @desc    Create new inventory item
 * @access  Public (should be protected in production)
 */
router.post('/', createInventory);

/**
 * @route   PUT /api/inventory/:id
 * @desc    Update inventory item
 * @access  Public (should be protected in production)
 */
router.put('/:id', updateInventory);

/**
 * @route   DELETE /api/inventory/:id
 * @desc    Delete inventory item
 * @access  Public (should be protected in production)
 */
router.delete('/:id', deleteInventory);

module.exports = router;
