const express = require('express');
const router = express.Router();
const {
  getAllRequests,
  getRequestById,
  createRequest,
  updateRequestStatus,
  deleteRequest,
  getTransferStats
} = require('../controllers/transferRequestController');

/**
 * @route   GET /api/transfers
 * @desc    Get all transfer requests
 * @access  Public
 */
router.get('/', getAllRequests);

/**
 * @route   GET /api/transfers/stats
 * @desc    Get transfer statistics
 * @access  Public
 */
router.get('/stats', getTransferStats);

/**
 * @route   GET /api/transfers/:id
 * @desc    Get single transfer request
 * @access  Public
 */
router.get('/:id', getRequestById);

/**
 * @route   POST /api/transfers
 * @desc    Create new transfer request
 * @access  Public (should be protected in production)
 */
router.post('/', createRequest);

/**
 * @route   PATCH /api/transfers/:id/status
 * @desc    Update transfer request status
 * @access  Public (should be protected in production)
 */
router.patch('/:id/status', updateRequestStatus);

/**
 * @route   DELETE /api/transfers/:id
 * @desc    Delete transfer request
 * @access  Public (should be protected in production)
 */
router.delete('/:id', deleteRequest);

module.exports = router;
