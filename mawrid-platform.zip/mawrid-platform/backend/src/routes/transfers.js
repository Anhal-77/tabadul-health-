const express = require('express');
const router = express.Router();
const transferRequestController = require('../controllers/transferRequestController');

// GET /api/transfers - Get all transfer requests
router.get('/', transferRequestController.getAll);

// GET /api/transfers/:id - Get single transfer request
router.get('/:id', transferRequestController.getById);

// POST /api/transfers - Create new transfer request
router.post('/', transferRequestController.create);

// PUT /api/transfers/:id/approve - Approve transfer request
router.put('/:id/approve', transferRequestController.approve);

// PUT /api/transfers/:id/ship - Mark as shipped
router.put('/:id/ship', transferRequestController.ship);

// PUT /api/transfers/:id/receive - Mark as received (complete transfer)
router.put('/:id/receive', transferRequestController.receive);

// PUT /api/transfers/:id/reject - Reject transfer request
router.put('/:id/reject', transferRequestController.reject);

module.exports = router;
