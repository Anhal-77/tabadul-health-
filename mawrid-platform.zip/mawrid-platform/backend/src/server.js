const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const { testConnection, sequelize } = require('./config/database');
const { syncDatabase } = require('./models');
const { initCronJobs } = require('./utils/cronJobs');
const errorHandler = require('./middleware/errorHandler');

// Import routes
const healthCenterRoutes = require('./routes/healthCenterRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const transferRequestRoutes = require('./routes/transferRequestRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');

// Initialize Express app
const app = express();

// Middleware
app.use(helmet()); // Security headers
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies
app.use(morgan('dev')); // HTTP request logger

// Welcome route
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'مرحباً بكم في منصة مورد - Mawrid Platform API',
    version: '1.0.0',
    endpoints: {
      health_centers: '/api/health-centers',
      inventory: '/api/inventory',
      transfers: '/api/transfers',
      analytics: '/api/analytics'
    }
  });
});

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    status: 'OK',
    timestamp: new Date(),
    uptime: process.uptime()
  });
});

// API Routes
app.use('/api/health-centers', healthCenterRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/transfers', transferRequestRoutes);
app.use('/api/analytics', analyticsRoutes);

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'المسار غير موجود'
  });
});

// Error handling middleware (must be last)
app.use(errorHandler);

// Server initialization
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    // Test database connection
    await testConnection();

    // Sync database models
    // Use { force: false } in production to prevent data loss
    // Use { alter: true } to update tables without dropping them
    await syncDatabase({ alter: true });

    // Initialize cron jobs
    initCronJobs();

    // Start server
    app.listen(PORT, () => {
      console.log(`
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║         🏥 Mawrid Platform API Server                ║
║         منصة مورد - إدارة الموارد الصحية            ║
║                                                       ║
║         Server running on port: ${PORT}                ║
║         Environment: ${process.env.NODE_ENV || 'development'}              ║
║         Database: Connected ✅                        ║
║                                                       ║
║         API Documentation:                            ║
║         http://localhost:${PORT}/                      ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
      `);
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Promise Rejection:', err);
  // Close server & exit process
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('👋 SIGTERM signal received: closing HTTP server');
  await sequelize.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('👋 SIGINT signal received: closing HTTP server');
  await sequelize.close();
  process.exit(0);
});

// Start the server
startServer();

module.exports = app;
