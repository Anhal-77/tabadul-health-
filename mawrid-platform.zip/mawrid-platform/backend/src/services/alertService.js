const { Op } = require('sequelize');
const { Inventory, HealthCenter } = require('../models');

class AlertService {
  constructor() {
    this.EXPIRY_WARNING_DAYS = parseInt(process.env.EXPIRY_WARNING_DAYS) || 90;
    this.CRITICAL_STOCK_THRESHOLD = parseInt(process.env.CRITICAL_STOCK_THRESHOLD) || 10;
  }

  /**
   * Automatically update inventory status based on expiry dates
   */
  async updateInventoryStatus() {
    try {
      const today = new Date();
      const warningDate = new Date();
      warningDate.setDate(today.getDate() + this.EXPIRY_WARNING_DAYS);

      // Update items to 'surplus' if expiring within warning period
      const surplusUpdate = await Inventory.update(
        { status: 'surplus' },
        {
          where: {
            expiry_date: {
              [Op.lte]: warningDate,
              [Op.gt]: today
            },
            quantity: {
              [Op.gt]: 0
            },
            status: {
              [Op.notIn]: ['expired', 'reserved']
            }
          }
        }
      );

      // Update items to 'expired' if past expiry date
      const expiredUpdate = await Inventory.update(
        { status: 'expired' },
        {
          where: {
            expiry_date: {
              [Op.lt]: today
            },
            status: {
              [Op.ne]: 'expired'
            }
          }
        }
      );

      // Update items to 'critical' if quantity is low
      const criticalUpdate = await Inventory.update(
        { status: 'critical' },
        {
          where: {
            quantity: {
              [Op.lte]: this.CRITICAL_STOCK_THRESHOLD,
              [Op.gt]: 0
            },
            expiry_date: {
              [Op.gt]: warningDate
            },
            status: 'available'
          }
        }
      );

      console.log(`✅ Status Update Complete:
        - ${surplusUpdate[0]} items marked as surplus
        - ${expiredUpdate[0]} items marked as expired
        - ${criticalUpdate[0]} items marked as critical`);

      return {
        surplus: surplusUpdate[0],
        expired: expiredUpdate[0],
        critical: criticalUpdate[0]
      };
    } catch (error) {
      console.error('❌ Error updating inventory status:', error);
      throw error;
    }
  }

  /**
   * Get all surplus items across all centers
   */
  async getSurplusItems(filters = {}) {
    try {
      const whereClause = {
        status: 'surplus',
        quantity: {
          [Op.gt]: 0
        }
      };

      if (filters.category) {
        whereClause.category = filters.category;
      }

      if (filters.city) {
        whereClause['$health_center.city$'] = filters.city;
      }

      const surplusItems = await Inventory.findAll({
        where: whereClause,
        include: [{
          model: HealthCenter,
          as: 'health_center',
          attributes: ['id', 'name', 'name_ar', 'city', 'contact_info']
        }],
        order: [['expiry_date', 'ASC']]
      });

      return surplusItems;
    } catch (error) {
      console.error('❌ Error fetching surplus items:', error);
      throw error;
    }
  }

  /**
   * Get expiring items for a specific center
   */
  async getExpiringItemsByCenter(centerId) {
    try {
      const today = new Date();
      const warningDate = new Date();
      warningDate.setDate(today.getDate() + this.EXPIRY_WARNING_DAYS);

      const expiringItems = await Inventory.findAll({
        where: {
          center_id: centerId,
          expiry_date: {
            [Op.lte]: warningDate,
            [Op.gt]: today
          },
          quantity: {
            [Op.gt]: 0
          }
        },
        order: [['expiry_date', 'ASC']]
      });

      return expiringItems;
    } catch (error) {
      console.error('❌ Error fetching expiring items:', error);
      throw error;
    }
  }

  /**
   * Get analytics on waste prevention
   */
  async getWastePrevention() {
    try {
      const { sequelize } = require('../config/database');
      const TransferRequest = require('../models/TransferRequest');

      // Calculate total value of items that were saved from expiration
      const savedItems = await TransferRequest.findAll({
        where: {
          status: 'received'
        },
        include: [{
          model: Inventory,
          as: 'inventory_item',
          attributes: ['unit_price', 'item_name', 'category']
        }],
        attributes: ['quantity', 'estimated_value']
      });

      let totalSaved = 0;
      let itemsSaved = 0;

      savedItems.forEach(request => {
        const value = request.estimated_value || 
                     (request.quantity * (request.inventory_item?.unit_price || 0));
        totalSaved += parseFloat(value);
        itemsSaved += request.quantity;
      });

      // Get surplus items statistics
      const surplusStats = await Inventory.findAll({
        where: {
          status: 'surplus'
        },
        attributes: [
          'category',
          [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
          [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity'],
          [sequelize.fn('SUM', sequelize.col('total_value')), 'total_value']
        ],
        group: ['category']
      });

      return {
        total_value_saved: totalSaved.toFixed(2),
        total_items_saved: itemsSaved,
        current_surplus: surplusStats,
        last_updated: new Date()
      };
    } catch (error) {
      console.error('❌ Error calculating waste prevention:', error);
      throw error;
    }
  }
}

module.exports = new AlertService();
