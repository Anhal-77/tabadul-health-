const cron = require('node-cron');
const alertService = require('../services/alertService');

/**
 * Initialize cron jobs for automated tasks
 */
const initCronJobs = () => {
  
  // Run every day at 2:00 AM to update inventory status
  cron.schedule('0 2 * * *', async () => {
    console.log('🕐 Running daily inventory status update...');
    try {
      await alertService.updateInventoryStatus();
      console.log('✅ Daily inventory status update completed');
    } catch (error) {
      console.error('❌ Error in daily inventory update:', error);
    }
  });

  // Run every 6 hours to check for critical items
  cron.schedule('0 */6 * * *', async () => {
    console.log('🕐 Running critical stock check...');
    try {
      const result = await alertService.updateInventoryStatus();
      if (result.critical > 0) {
        console.log(`⚠️  Found ${result.critical} critical stock items`);
        // Here you can add email notification logic
      }
    } catch (error) {
      console.error('❌ Error in critical stock check:', error);
    }
  });

  console.log('✅ Cron jobs initialized successfully');
};

module.exports = { initCronJobs };
