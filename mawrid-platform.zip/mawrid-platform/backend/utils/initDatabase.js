const { sequelize, HealthCenter, Inventory, TransferRequest, syncDatabase } = require('../models');
require('dotenv').config();

const initializeDatabase = async () => {
  try {
    console.log('🔄 Initializing database...');
    
    // Sync database (this will create tables)
    await syncDatabase(true); // force: true will drop existing tables
    
    console.log('✅ Tables created successfully');
    console.log('📝 Inserting sample data...');
    
    // Create Health Centers
    const centers = await HealthCenter.bulkCreate([
      {
        name: 'مركز الملك فهد الصحي',
        city: 'الرياض',
        contact_info: {
          phone: '+966-11-1234567',
          email: 'info@kfhc.sa',
          address: 'طريق الملك فهد، الرياض'
        }
      },
      {
        name: 'مركز الأمير سلطان الطبي',
        city: 'جدة',
        contact_info: {
          phone: '+966-12-2345678',
          email: 'contact@psmc.sa',
          address: 'شارع فلسطين، جدة'
        }
      },
      {
        name: 'مركز الدمام الصحي الشامل',
        city: 'الدمام',
        contact_info: {
          phone: '+966-13-3456789',
          email: 'info@dhc.sa',
          address: 'الكورنيش، الدمام'
        }
      },
      {
        name: 'مركز المدينة الطبي',
        city: 'المدينة المنورة',
        contact_info: {
          phone: '+966-14-4567890',
          email: 'contact@mmc.sa',
          address: 'طريق الملك عبدالعزيز، المدينة المنورة'
        }
      },
      {
        name: 'مركز الطائف للرعاية الصحية',
        city: 'الطائف',
        contact_info: {
          phone: '+966-12-5678901',
          email: 'info@thc.sa',
          address: 'الحوية، الطائف'
        }
      }
    ]);
    
    console.log(`✅ Created ${centers.length} health centers`);
    
    // Create Inventory Items
    const today = new Date();
    const inventoryItems = [];
    
    // Center 1 - Riyadh (has surplus items)
    inventoryItems.push(
      {
        center_id: centers[0].id,
        item_name: 'أمبيسيلين 500 ملغ',
        category: 'medicine',
        batch_number: 'AMP-2024-001',
        quantity: 150,
        expiry_date: new Date(today.getTime() + 60 * 24 * 60 * 60 * 1000), // 60 days
        unit_price: 12.50,
        description: 'مضاد حيوي واسع الطيف'
      },
      {
        center_id: centers[0].id,
        item_name: 'قفازات طبية معقمة',
        category: 'medical_supplies',
        batch_number: 'GLV-2024-001',
        quantity: 200,
        expiry_date: new Date(today.getTime() + 45 * 24 * 60 * 60 * 1000), // 45 days
        unit_price: 0.75,
        description: 'قفازات لاتكس معقمة'
      },
      {
        center_id: centers[0].id,
        item_name: 'أدوات فحص الأسنان',
        category: 'dental_equipment',
        batch_number: 'DNT-2024-001',
        quantity: 50,
        expiry_date: new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000), // 30 days
        unit_price: 85.00,
        description: 'مجموعة أدوات فحص الأسنان الأساسية'
      }
    );
    
    // Center 2 - Jeddah (has critical items)
    inventoryItems.push(
      {
        center_id: centers[1].id,
        item_name: 'باراسيتامول 500 ملغ',
        category: 'medicine',
        batch_number: 'PAR-2024-002',
        quantity: 8,
        expiry_date: new Date(today.getTime() + 180 * 24 * 60 * 60 * 1000),
        unit_price: 5.00,
        description: 'مسكن للألم وخافض للحرارة'
      },
      {
        center_id: centers[1].id,
        item_name: 'أجهزة قياس الضغط',
        category: 'diagnostic_tools',
        batch_number: 'BP-2024-001',
        quantity: 5,
        expiry_date: new Date(today.getTime() + 365 * 24 * 60 * 60 * 1000),
        unit_price: 120.00,
        description: 'أجهزة قياس ضغط الدم الرقمية'
      }
    );
    
    // Center 3 - Dammam
    inventoryItems.push(
      {
        center_id: centers[2].id,
        item_name: 'إبر حقن معقمة',
        category: 'medical_supplies',
        batch_number: 'SYR-2024-001',
        quantity: 100,
        expiry_date: new Date(today.getTime() + 150 * 24 * 60 * 60 * 1000),
        unit_price: 1.50,
        description: 'إبر حقن معقمة مقاس مختلفة'
      },
      {
        center_id: centers[2].id,
        item_name: 'معجون أسنان طبي',
        category: 'dental_equipment',
        batch_number: 'TP-2024-001',
        quantity: 75,
        expiry_date: new Date(today.getTime() + 70 * 24 * 60 * 60 * 1000), // 70 days - surplus
        unit_price: 15.00,
        description: 'معجون أسنان بالفلورايد'
      }
    );
    
    // Center 4 - Medina
    inventoryItems.push(
      {
        center_id: centers[3].id,
        item_name: 'ضمادات طبية معقمة',
        category: 'medical_supplies',
        batch_number: 'BND-2024-001',
        quantity: 120,
        expiry_date: new Date(today.getTime() + 200 * 24 * 60 * 60 * 1000),
        unit_price: 3.50,
        description: 'ضمادات طبية معقمة مختلفة الأحجام'
      }
    );
    
    // Center 5 - Taif
    inventoryItems.push(
      {
        center_id: centers[4].id,
        item_name: 'أدوات تنظيف الأسنان',
        category: 'dental_equipment',
        batch_number: 'DCL-2024-001',
        quantity: 40,
        expiry_date: new Date(today.getTime() + 55 * 24 * 60 * 60 * 1000), // 55 days - surplus
        unit_price: 45.00,
        description: 'أدوات تنظيف وتلميع الأسنان'
      },
      {
        center_id: centers[4].id,
        item_name: 'محاليل وريدية',
        category: 'medicine',
        batch_number: 'IV-2024-001',
        quantity: 6,
        expiry_date: new Date(today.getTime() + 90 * 24 * 60 * 60 * 1000),
        unit_price: 25.00,
        description: 'محلول ملحي للحقن الوريدي'
      }
    );
    
    const items = await Inventory.bulkCreate(inventoryItems);
    console.log(`✅ Created ${items.length} inventory items`);
    
    // Create Sample Transfer Requests
    const transfers = await TransferRequest.bulkCreate([
      {
        item_id: items[0].id, // Ampicillin from Riyadh
        sender_center_id: centers[0].id,
        receiver_center_id: centers[1].id,
        quantity: 50,
        status: 'pending',
        request_notes: 'نحتاج إلى أمبيسيلين بشكل عاجل'
      },
      {
        item_id: items[2].id, // Dental tools from Riyadh
        sender_center_id: centers[0].id,
        receiver_center_id: centers[3].id,
        quantity: 20,
        status: 'approved',
        request_notes: 'طلب نقل أدوات فحص الأسنان',
        approved_at: new Date()
      },
      {
        item_id: items[6].id, // Dental paste from Dammam
        sender_center_id: centers[2].id,
        receiver_center_id: centers[4].id,
        quantity: 30,
        status: 'received',
        request_notes: 'نقل معجون أسنان طبي',
        approved_at: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000),
        shipped_at: new Date(today.getTime() - 3 * 24 * 60 * 60 * 1000),
        received_at: new Date(today.getTime() - 1 * 24 * 60 * 60 * 1000)
      }
    ]);
    
    console.log(`✅ Created ${transfers.length} transfer requests`);
    
    console.log('\n✅ Database initialization completed successfully!');
    console.log('\n📊 Summary:');
    console.log(`   - Health Centers: ${centers.length}`);
    console.log(`   - Inventory Items: ${items.length}`);
    console.log(`   - Transfer Requests: ${transfers.length}`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    process.exit(1);
  }
};

// Run initialization
initializeDatabase();
