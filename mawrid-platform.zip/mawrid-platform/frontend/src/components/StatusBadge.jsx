import React from 'react';
import { AlertCircle, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

const StatusBadge = ({ status }) => {
  const statusConfig = {
    available: {
      label: 'متوفر',
      color: 'badge-success',
      icon: CheckCircle,
    },
    surplus: {
      label: 'فائض',
      color: 'badge-warning',
      icon: AlertTriangle,
    },
    critical: {
      label: 'حرج',
      color: 'badge-danger',
      icon: AlertCircle,
    },
    expired: {
      label: 'منتهي',
      color: 'badge-danger',
      icon: XCircle,
    },
    pending: {
      label: 'قيد الانتظار',
      color: 'badge-info',
      icon: AlertCircle,
    },
    approved: {
      label: 'موافق عليه',
      color: 'badge-success',
      icon: CheckCircle,
    },
    rejected: {
      label: 'مرفوض',
      color: 'badge-danger',
      icon: XCircle,
    },
    shipped: {
      label: 'تم الشحن',
      color: 'badge-info',
      icon: CheckCircle,
    },
    received: {
      label: 'تم الاستلام',
      color: 'badge-success',
      icon: CheckCircle,
    },
    cancelled: {
      label: 'ملغي',
      color: 'badge-danger',
      icon: XCircle,
    },
  };
  
  const config = statusConfig[status] || statusConfig.available;
  const Icon = config.icon;
  
  return (
    <span className={`badge ${config.color} inline-flex items-center gap-1`}>
      <Icon className="h-4 w-4" />
      {config.label}
    </span>
  );
};

export default StatusBadge;
