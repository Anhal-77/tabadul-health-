import React from 'react';

const StatusBadge = ({ status, type = 'inventory' }) => {
  const getInventoryStyle = () => {
    switch (status) {
      case 'available':
        return 'badge-success';
      case 'surplus':
        return 'badge-warning';
      case 'critical':
        return 'badge-danger';
      case 'expired':
        return 'bg-gray-200 text-gray-700';
      default:
        return 'badge-info';
    }
  };

  const getTransferStyle = () => {
    switch (status) {
      case 'pending':
        return 'badge-warning';
      case 'approved':
        return 'badge-info';
      case 'shipped':
        return 'bg-purple-100 text-purple-700';
      case 'received':
        return 'badge-success';
      case 'rejected':
      case 'cancelled':
        return 'badge-danger';
      default:
        return 'badge-info';
    }
  };

  const getInventoryLabel = () => {
    switch (status) {
      case 'available':
        return 'متوفر';
      case 'surplus':
        return 'فائض';
      case 'critical':
        return 'حرج';
      case 'expired':
        return 'منتهي';
      default:
        return status;
    }
  };

  const getTransferLabel = () => {
    switch (status) {
      case 'pending':
        return 'قيد الانتظار';
      case 'approved':
        return 'موافق عليه';
      case 'shipped':
        return 'قيد الشحن';
      case 'received':
        return 'مستلم';
      case 'rejected':
        return 'مرفوض';
      case 'cancelled':
        return 'ملغي';
      default:
        return status;
    }
  };

  const badgeClass = type === 'inventory' ? getInventoryStyle() : getTransferStyle();
  const label = type === 'inventory' ? getInventoryLabel() : getTransferLabel();

  return <span className={`badge ${badgeClass}`}>{label}</span>;
};

export default StatusBadge;
