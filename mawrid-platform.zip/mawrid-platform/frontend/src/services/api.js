import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Health Centers API
export const healthCentersAPI = {
  getAll: (params) => api.get('/health-centers', { params }),
  getById: (id) => api.get(`/health-centers/${id}`),
  create: (data) => api.post('/health-centers', data),
  update: (id, data) => api.put(`/health-centers/${id}`, data),
  delete: (id) => api.delete(`/health-centers/${id}`),
  getStats: () => api.get('/health-centers/stats'),
};

// Inventory API
export const inventoryAPI = {
  getAll: (params) => api.get('/inventory', { params }),
  getById: (id) => api.get(`/inventory/${id}`),
  create: (data) => api.post('/inventory', data),
  update: (id, data) => api.put(`/inventory/${id}`, data),
  delete: (id) => api.delete(`/inventory/${id}`),
  getSurplus: (params) => api.get('/inventory/surplus', { params }),
  getStats: () => api.get('/inventory/stats'),
};

// Transfer Requests API
export const transfersAPI = {
  getAll: (params) => api.get('/transfers', { params }),
  getById: (id) => api.get(`/transfers/${id}`),
  create: (data) => api.post('/transfers', data),
  updateStatus: (id, data) => api.patch(`/transfers/${id}/status`, data),
  delete: (id) => api.delete(`/transfers/${id}`),
  getStats: () => api.get('/transfers/stats'),
};

// Analytics API
export const analyticsAPI = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getWastePrevention: () => api.get('/analytics/waste-prevention'),
  getCenterAnalytics: (centerId) => api.get(`/analytics/center/${centerId}`),
};

export default api;
